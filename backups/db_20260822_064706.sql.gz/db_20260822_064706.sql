--
-- PostgreSQL database dump
--

\restrict mLbbTSjqbf1DCeWn8TVa4oAodipCdjQhoaDTq69zaikG75YwWUN4IaFkgNccKLG

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text,
    user_name text,
    action text,
    resource_type text,
    resource_id text,
    details text,
    ip_address text,
    user_agent text,
    severity text,
    metadata text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: base44_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.base44_purchases (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    checkoutsessionid text,
    status text,
    user_id text,
    user_name text,
    plan_id text,
    plan_name text,
    expected_amount numeric,
    expected_currency text,
    entitlement text,
    is_trial boolean,
    promo_code text,
    fulfilled boolean,
    payment_id text,
    subscription_id text,
    paid_at timestamp with time zone,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blog_posts (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text,
    category text,
    author_name text,
    author_id text,
    featured_image_url text,
    status text DEFAULT 'draft'::text NOT NULL,
    published_date timestamp(3) without time zone,
    tags text[] DEFAULT ARRAY[]::text[],
    read_time integer,
    is_featured boolean DEFAULT false NOT NULL
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    business_id text,
    business_name text,
    user_id text,
    user_name text,
    user_email text,
    user_phone text,
    booking_type text,
    booking_date timestamp with time zone,
    booking_time text,
    party_size numeric,
    notes text,
    status text,
    confirmed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancellation_reason text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: business_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_categories (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    name text,
    description text,
    icon text,
    slug text,
    parent_id text,
    sort_order numeric,
    is_active boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: business_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_documents (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    document_type text,
    file_url text,
    file_name text,
    status text,
    expiry_date timestamp(3) without time zone,
    uploaded_by_id text,
    uploaded_by_name text,
    verified_by_id text,
    verified_date timestamp(3) without time zone,
    rejection_reason text,
    description text
);


--
-- Name: business_email_blasts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_email_blasts (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    business_category text,
    scope text,
    target_country text,
    target_city text,
    target_area text,
    subject text,
    body text,
    audience_count integer DEFAULT 0 NOT NULL,
    price double precision,
    currency text,
    status text,
    checkout_session_id text,
    payment_id text,
    review_notes text,
    reviewed_by_id text,
    reviewed_at timestamp(3) without time zone,
    sent_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    error_message text
);


--
-- Name: business_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_locations (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    name text,
    address text,
    city text,
    country text,
    postal_code text,
    latitude double precision,
    longitude double precision,
    phone text,
    email text,
    business_hours jsonb,
    is_primary boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    description text
);


--
-- Name: businesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.businesses (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    owner_id text,
    description text,
    category text,
    website text,
    logo_url text,
    is_active boolean DEFAULT true NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    business_email text,
    business_phone text
);


--
-- Name: campaign_audience; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_audience (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    campaign_id text,
    campaign_title text,
    user_id text,
    user_name text,
    status text,
    sent_at timestamp(3) without time zone,
    delivered_at timestamp(3) without time zone,
    read_at timestamp(3) without time zone,
    responded_at timestamp(3) without time zone,
    description text
);


--
-- Name: campaign_audiences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_audiences (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    campaign_id text,
    campaign_title text,
    user_id text,
    user_name text,
    status text,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    read_at timestamp with time zone,
    responded_at timestamp with time zone,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: campaign_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaign_messages (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    campaign_id text,
    campaign_title text,
    channel text,
    subject text,
    body text,
    scheduled_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    status text,
    recipient_count integer DEFAULT 0 NOT NULL,
    open_count integer DEFAULT 0 NOT NULL,
    click_count integer DEFAULT 0 NOT NULL
);


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campaigns (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    title text NOT NULL,
    description text,
    type text,
    status text DEFAULT 'draft'::text NOT NULL,
    channels text[] DEFAULT ARRAY[]::text[],
    message_subject text,
    message_body text,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    scheduled_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    target_audience text,
    target_city text,
    audience_filters jsonb,
    total_recipients integer DEFAULT 0 NOT NULL,
    delivered_count integer DEFAULT 0 NOT NULL,
    opened_count integer DEFAULT 0 NOT NULL,
    clicked_count integer DEFAULT 0 NOT NULL,
    conversion_count integer DEFAULT 0 NOT NULL,
    coupon_id text,
    gift_campaign_id text,
    image_url text,
    opt_in_only boolean DEFAULT false NOT NULL
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    conversation_id text,
    business_id text,
    business_name text,
    user_id text,
    user_name text,
    business_owner_id text,
    sender_type text,
    sender_id text,
    sender_name text,
    content text,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp(3) without time zone
);


--
-- Name: commission_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commission_payments (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    partner_id text,
    partner_name text,
    partner_email text,
    period text,
    gross_amount numeric,
    commission_rate numeric,
    net_amount numeric,
    currency text,
    status text,
    payment_method text,
    payment_date timestamp with time zone,
    transaction_reference text,
    referral_count numeric,
    breakdown text,
    notes text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: compliance_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_requests (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    user_email text,
    request_type text,
    status text,
    description text,
    consent_type text,
    consent_value text,
    processed_by_id text,
    processed_by_name text,
    processed_at timestamp(3) without time zone,
    export_url text,
    deletion_scheduled_at timestamp(3) without time zone,
    retention_category text,
    retention_days integer,
    resolution_notes text
);


--
-- Name: config_change_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_change_logs (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    entity_type text,
    entity_id text,
    entity_key text,
    action text,
    previous_value text,
    new_value text,
    changed_by_id text,
    changed_by_name text,
    change_reason text,
    is_critical boolean DEFAULT false NOT NULL,
    description text
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    code text NOT NULL,
    title text,
    description text,
    discount_percentage double precision,
    valid_from timestamp(3) without time zone,
    valid_to timestamp(3) without time zone,
    usage_limit integer,
    used_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    premium_only boolean DEFAULT false NOT NULL
);


--
-- Name: crm_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crm_records (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    user_id text,
    customer_name text,
    vip_flag boolean DEFAULT false NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    lifecycle_status text,
    marketing_consent boolean DEFAULT false NOT NULL,
    internal_notes text,
    follow_up_tasks jsonb,
    custom_fields jsonb,
    preferred_contact_method text,
    last_contacted_date timestamp(3) without time zone,
    description text
);


--
-- Name: developer_apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.developer_apps (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    description text,
    app_type text,
    status text,
    scopes text[] DEFAULT ARRAY[]::text[],
    redirect_uri text,
    api_key text NOT NULL,
    api_secret_hash text,
    webhook_url text,
    webhook_secret text,
    webhook_events text[] DEFAULT ARRAY[]::text[],
    rate_limit_per_min integer DEFAULT 60 NOT NULL,
    ip_whitelist text[] DEFAULT ARRAY[]::text[],
    total_requests integer DEFAULT 0 NOT NULL,
    requests_today integer DEFAULT 0 NOT NULL,
    last_request_at timestamp(3) without time zone,
    owner_name text
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    device_type text,
    device_id text,
    device_name text,
    os_version text,
    app_version text,
    push_token text,
    last_seen timestamp(3) without time zone,
    ip_address text,
    is_active boolean DEFAULT true NOT NULL,
    is_trusted boolean DEFAULT false NOT NULL,
    description text
);


--
-- Name: discounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discounts (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    title text NOT NULL,
    description text,
    percentage double precision,
    category text,
    tags text[] DEFAULT ARRAY[]::text[],
    image_url text,
    min_purchase_amount double precision,
    max_discount_amount double precision,
    valid_from timestamp(3) without time zone,
    valid_to timestamp(3) without time zone,
    usage_limit integer,
    used_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    premium_only boolean DEFAULT false NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    is_limited_time boolean DEFAULT false NOT NULL,
    terms_conditions text,
    eligible_branch_ids text[] DEFAULT ARRAY[]::text[],
    redemption_requirements text,
    view_count integer DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: disputes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disputes (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    business_owner_id text,
    transaction_id text,
    qr_code_id text,
    reason text,
    description text,
    evidence_urls text,
    status text,
    business_response text,
    business_responded_at timestamp with time zone,
    resolution_notes text,
    refund_amount numeric,
    refund_issued boolean,
    sla_due_at timestamp with time zone,
    escalated_at timestamp with time zone,
    resolved_at timestamp with time zone,
    resolved_by_id text,
    timeline text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: employee_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_schedules (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    employee_id text,
    employee_name text,
    business_id text,
    business_name text,
    branch_id text,
    branch_name text,
    weekday text,
    start_time text,
    end_time text,
    break_minutes integer DEFAULT 0 NOT NULL,
    is_recurring boolean DEFAULT true NOT NULL,
    specific_date timestamp(3) without time zone,
    clock_in_time timestamp(3) without time zone,
    clock_out_time timestamp(3) without time zone,
    status text,
    notes text
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    user_id text,
    full_name text,
    email text,
    phone text,
    role text,
    permissions text[] DEFAULT ARRAY[]::text[],
    is_active boolean DEFAULT true NOT NULL,
    hired_date timestamp(3) without time zone,
    branch_id text,
    branch_name text,
    description text
);


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorites (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    category text,
    discount_id text,
    discount_title text,
    collection_name text,
    notify_on_change boolean DEFAULT false NOT NULL,
    is_watched boolean DEFAULT false NOT NULL,
    description text
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    name text,
    description text,
    key text,
    is_enabled boolean,
    rollout_strategy text,
    target_countries text,
    target_user_groups text,
    rollout_percentage numeric,
    scheduled_activation_at timestamp with time zone,
    scheduled_deactivation_at timestamp with time zone,
    created_by_id text,
    created_by_name text,
    updated_by_id text,
    updated_by_name text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: gift_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gift_campaigns (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    title text NOT NULL,
    description text,
    gift_type text,
    value double precision,
    value_unit text,
    trigger_type text,
    audience_type text,
    target_user_ids text[] DEFAULT ARRAY[]::text[],
    segment_rules jsonb,
    milestone_metric text,
    milestone_threshold double precision,
    valid_from timestamp(3) without time zone,
    valid_to timestamp(3) without time zone,
    expiry_days integer,
    total_quantity integer,
    claimed_quantity integer DEFAULT 0 NOT NULL,
    redeemed_quantity integer DEFAULT 0 NOT NULL,
    per_customer_limit integer DEFAULT 1 NOT NULL,
    points_reward integer,
    status text,
    image_url text,
    scheduled_at timestamp(3) without time zone,
    sent_count integer DEFAULT 0 NOT NULL
);


--
-- Name: gift_redemptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gift_redemptions (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    gift_campaign_id text,
    gift_campaign_title text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    awarded_date timestamp with time zone,
    redeemed_date timestamp with time zone,
    expiry_date timestamp with time zone,
    status text,
    redemption_code text,
    gift_type_snapshot text,
    gift_value_snapshot numeric,
    gift_value_unit_snapshot text,
    source text,
    points_awarded numeric,
    transaction_id text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    payment_id text,
    subscription_id text,
    invoice_number text NOT NULL,
    amount double precision,
    currency text,
    tax_rate double precision,
    tax_amount double precision,
    total_amount double precision,
    billing_period text,
    status text,
    issue_date timestamp(3) without time zone,
    due_date timestamp(3) without time zone,
    paid_date timestamp(3) without time zone,
    pdf_url text,
    line_items jsonb,
    refund_amount double precision,
    refunded_at timestamp(3) without time zone,
    refund_reason text,
    notes text
);


--
-- Name: knowledge_bases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_bases (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    title text,
    content text,
    summary text,
    category text,
    subcategory text,
    article_type text,
    tags text,
    is_published boolean,
    is_featured boolean,
    status text,
    language text,
    video_url text,
    screenshots text,
    sort_order numeric,
    version numeric,
    approved_by_id text,
    approved_by_name text,
    approved_at timestamp with time zone,
    translation_key text,
    view_count numeric,
    helpful_count numeric,
    unhelpful_count numeric,
    author_id text,
    author_name text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: loyalty_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_points (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    points integer DEFAULT 0 NOT NULL,
    points_type text,
    expiry_date timestamp(3) without time zone
);


--
-- Name: loyalty_tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_tiers (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    level_name text,
    min_points integer DEFAULT 0 NOT NULL,
    max_points integer,
    color text,
    icon text,
    benefits text[] DEFAULT ARRAY[]::text[],
    points_multiplier double precision DEFAULT 1 NOT NULL,
    discount_bonus double precision,
    priority_support boolean DEFAULT false NOT NULL,
    free_monthly_gift boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    description text
);


--
-- Name: membership_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_plans (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    description text,
    plan_type text,
    price double precision DEFAULT 0 NOT NULL,
    original_price double precision,
    currency text DEFAULT 'EUR'::text NOT NULL,
    billing_cycle text DEFAULT 'monthly'::text NOT NULL,
    features text[] DEFAULT ARRAY[]::text[],
    feature_entitlements jsonb,
    trial_days integer DEFAULT 0 NOT NULL,
    is_promotional boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    archived_at timestamp(3) without time zone,
    sort_order integer DEFAULT 0 NOT NULL,
    max_discount_percentage double precision
);


--
-- Name: newsletter_subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.newsletter_subscribers (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    email text NOT NULL,
    name text,
    source text,
    is_active boolean DEFAULT true NOT NULL,
    subscribed_at timestamp(3) without time zone,
    description text
);


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    key text NOT NULL,
    channel text,
    subject text,
    body text,
    variables jsonb,
    language text DEFAULT 'en'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    previous_body text,
    previous_subject text,
    previous_version integer,
    created_by_id text,
    created_by_name text,
    updated_by_id text,
    updated_by_name text
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    title text NOT NULL,
    message text NOT NULL,
    description text,
    type text,
    priority text,
    is_read boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    action_url text,
    action_label text,
    channel text,
    sent_at timestamp(3) without time zone,
    read_at timestamp(3) without time zone,
    clicked_at timestamp(3) without time zone,
    image_url text,
    business_id text,
    business_name text
);


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    user_id text,
    phone_number text,
    code_hash text,
    delivery_method text,
    expires_at timestamp with time zone,
    attempts numeric,
    verified boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: outreach_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outreach_campaigns (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    title text NOT NULL,
    description text,
    target_category text,
    target_city text,
    target_country text,
    email_subject text,
    email_body text,
    recipients text[] DEFAULT ARRAY[]::text[],
    status text,
    total_recipients integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    response_count integer DEFAULT 0 NOT NULL,
    sent_at timestamp(3) without time zone,
    created_by_name text
);


--
-- Name: partner_referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.partner_referrals (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    partner_id text,
    partner_name text,
    partner_email text,
    referral_code text NOT NULL,
    referred_email text,
    referred_name text,
    referral_type text,
    status text,
    signed_up_date timestamp(3) without time zone,
    converted_date timestamp(3) without time zone,
    churned_date timestamp(3) without time zone,
    commission_rate double precision,
    monthly_commission double precision,
    total_commission_earned double precision,
    is_active boolean DEFAULT true NOT NULL,
    description text
);


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    user_id text,
    user_name text,
    type text,
    provider text,
    provider_payment_method_id text,
    last4 text,
    brand text,
    expiry_month numeric,
    expiry_year numeric,
    is_default boolean,
    is_active boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    subscription_id text,
    campaign_id text,
    payment_method_id text,
    amount double precision,
    currency text,
    payment_type text,
    status text,
    transaction_id text,
    provider text,
    provider_transaction_id text,
    paid_at timestamp(3) without time zone,
    failure_reason text,
    refund_amount double precision,
    refunded_at timestamp(3) without time zone,
    description text
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    description text,
    resource text,
    action text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_codes (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    code text NOT NULL,
    qr_token text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    generated_date timestamp(3) without time zone,
    activated_date timestamp(3) without time zone,
    deactivated_date timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    scan_count integer DEFAULT 0 NOT NULL,
    last_scan_date timestamp(3) without time zone,
    description text
);


--
-- Name: review_replies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_replies (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    review_id text,
    business_id text,
    business_name text,
    author_name text,
    author_id text,
    content text,
    is_business_reply boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_draft boolean DEFAULT false NOT NULL,
    edited_at timestamp(3) without time zone,
    content_history jsonb
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    rating integer,
    comment text,
    customer_name text,
    customer_id text,
    branch_id text,
    branch_name text,
    employee_id text,
    employee_name text,
    transaction_id text,
    resolution_status text,
    is_verified boolean DEFAULT false NOT NULL,
    sentiment text,
    tags text[] DEFAULT ARRAY[]::text[],
    description text
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    name text,
    description text,
    is_system boolean,
    is_active boolean,
    sort_order numeric,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: saved_segments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_segments (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    business_id text,
    business_name text,
    name text,
    description text,
    criteria text,
    match_count numeric,
    created_by_id text,
    created_by_name text,
    is_active boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: scheduled_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_reports (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    description text,
    report_type text,
    format text,
    frequency text,
    recipient_email text,
    filters jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_sent_at timestamp(3) without time zone,
    next_run_at timestamp(3) without time zone,
    created_by_id text,
    created_by_name text,
    business_id text
);


--
-- Name: security_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_incidents (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    title text NOT NULL,
    description text,
    type text,
    severity text,
    status text,
    target_user_id text,
    target_user_name text,
    target_business_id text,
    target_business_name text,
    assigned_to_id text,
    assigned_to_name text,
    created_by_id text,
    created_by_name text,
    resolution_notes text,
    resolved_at timestamp(3) without time zone,
    containment_actions text[] DEFAULT ARRAY[]::text[],
    affected_records integer,
    evidence jsonb
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    device_info text,
    ip_address text,
    user_agent text,
    expires_at timestamp(3) without time zone NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_activity timestamp(3) without time zone,
    description text
);


--
-- Name: sla_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_configs (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    description text,
    priority text,
    category text,
    first_response_hours double precision,
    resolution_hours double precision,
    escalation_enabled boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    business_id text,
    business_name text,
    plan_id text,
    plan_name text,
    plan_type text,
    amount double precision,
    currency text,
    billing_cycle text,
    status text,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    trial_end_date timestamp(3) without time zone,
    auto_renew boolean DEFAULT true NOT NULL,
    payment_method_id text,
    payment_id text,
    cancellation_reason text,
    cancelled_at timestamp(3) without time zone,
    renewal_count integer DEFAULT 0 NOT NULL,
    description text
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id text,
    user_name text,
    user_email text,
    business_id text,
    business_name text,
    subject text,
    description text,
    status text,
    priority text,
    category text,
    assigned_to_id text,
    assigned_to_name text,
    resolved_at timestamp with time zone,
    resolution_notes text,
    source text,
    requester_type text,
    sla_due_at timestamp with time zone,
    first_response_at timestamp with time zone,
    csat_rating numeric,
    csat_comment text,
    merged_into_id text,
    is_escalated boolean,
    tags text,
    attachments text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    key text NOT NULL,
    value text,
    description text,
    category text,
    is_public boolean DEFAULT false NOT NULL,
    is_encrypted boolean DEFAULT false NOT NULL,
    is_critical boolean DEFAULT false NOT NULL,
    previous_value text,
    updated_by_id text,
    updated_by_name text
);


--
-- Name: tax_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_configs (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    country text,
    country_code text,
    tax_name text,
    tax_rate numeric,
    applies_to text,
    is_active boolean,
    created_by_id text,
    created_by_name text,
    updated_by_id text,
    updated_by_name text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_messages (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    ticket_id text,
    sender_id text,
    sender_name text,
    sender_role text,
    body text,
    attachments text,
    is_internal_note boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    business_id text,
    business_name text,
    customer_id text,
    customer_name text,
    discount_percentage double precision,
    original_amount double precision,
    discount_amount double precision,
    final_amount double precision,
    status text,
    transaction_date timestamp(3) without time zone,
    description text
);


--
-- Name: user_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_memberships (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    user_id text,
    user_name text,
    membership_id text,
    plan_id text,
    plan_name text,
    qr_code_id text,
    status text,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    cancellation_reason text,
    cancellation_feedback text,
    cancelled_at timestamp(3) without time zone,
    grace_period_ends_at timestamp(3) without time zone,
    refund_issued boolean DEFAULT false NOT NULL,
    refund_amount double precision,
    description text
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    email text NOT NULL,
    password_hash text,
    full_name text,
    role text DEFAULT 'member'::text NOT NULL,
    business_id text,
    phone text,
    is_active boolean DEFAULT true NOT NULL,
    avatar_url text
);


--
-- Name: webhook_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_configs (
    id text NOT NULL,
    created_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date timestamp(3) without time zone NOT NULL,
    created_by text,
    name text NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT ARRAY[]::text[],
    is_active boolean DEFAULT true NOT NULL,
    secret text,
    headers jsonb,
    last_triggered_at timestamp(3) without time zone,
    last_status text,
    failure_count integer DEFAULT 0 NOT NULL,
    created_by_id text,
    created_by_name text,
    business_id text
);


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    description text,
    app_id text,
    app_name text,
    event_type text,
    url text,
    method text,
    payload text,
    response_status numeric,
    response_body text,
    attempt_count numeric,
    duration_ms numeric,
    status text,
    next_retry_at timestamp with time zone,
    error_message text,
    is_test boolean,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now(),
    created_by text
);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, user_name, action, resource_type, resource_id, details, ip_address, user_agent, severity, metadata, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: base44_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.base44_purchases (id, checkoutsessionid, status, user_id, user_name, plan_id, plan_name, expected_amount, expected_currency, entitlement, is_trial, promo_code, fulfilled, payment_id, subscription_id, paid_at, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blog_posts (id, created_date, updated_date, created_by, title, slug, excerpt, content, category, author_name, author_id, featured_image_url, status, published_date, tags, read_time, is_featured) FROM stdin;
6a5e080f9e4f1493062edd74	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	The Future of Local Loyalty: Why One Pass Is Going Global	future-of-local-loyalty	How a single digital pass is transforming the way premium members discover and support local businesses across Europe and beyond.	# The Future of Local Loyalty\n\nFor decades, loyalty programs lived in physical wallets: stamped paper cards, plastic key fobs, and drawer-fulls of expired coupons. One Pass is changing that.\n\n## The Problem with Traditional Loyalty\n\nLocal businesses have always offered discounts to repeat customers. But the system is broken:\n\n- **Customers** carry dozens of loyalty cards, most forgotten at home\n- **Businesses** run separate programs that are expensive to maintain and hard to track\n- **Discounts** are rarely discovered by new customers\n\n## A Single Pass, A Thousand Businesses\n\nOne Pass consolidates loyalty into one digital identity. With a single QR code, members unlock discounts at hundreds of participating businesses — restaurants, cafes, salons, gyms, and more.\n\n### The Value Proposition\n\n- **For members:** one pass, one QR code, consistent 5–20% savings everywhere\n- **For businesses:** free onboarding, instant access to premium customers, no physical cards to print\n- **For cities:** a network that drives foot traffic to local businesses over big chains\n\n## Going Global\n\nStarting in major European cities — Berlin, London, Paris, Madrid, Lisbon, Vienna, Prague, Amsterdam, Rome, Barcelona, Munich — One Pass is now expanding to new markets. Each city adds its own flavour: independent bookshops in Lisbon, vinyl bars in Berlin, trattorias in Madrid.\n\n## What's Next\n\nIn the coming months we're launching:\n- **Gift credits** so members can share discounts with friends\n- **AI-powered recommendations** based on your savings history\n- **Business analytics dashboards** so owners understand their customers better\n- **Developer API** so other apps can build on the One Pass network\n\n---\n\n*Local loyalty doesn't have to be local anymore. Join the network at [onepass.app](https://onepass.app).*	company	Anerium Team	\N	https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1200	published	2026-07-15 09:00:00	{loyalty,local-business,global,network,future}	4	t
6a5e080f9e4f1493062edd77	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	One Pass for Business: Why We Made Onboarding Free	free-business-onboarding	Our co-founder explains the decision to make One Pass business onboarding 100% free — and how the platform still sustains itself.	# Why One Pass Business Onboarding Is Free\n\nWhen we designed One Pass, we made a decision that surprised some investors: **listing a business would be free, forever.** Here's why.\n\n## The Loyalty Tax Is Wrong\n\nMost loyalty platforms charge businesses a monthly fee just to be listed. This creates a **loyalty tax** — only businesses that can afford the fee get visibility, and the smallest, most interesting local businesses are excluded.\n\nThat's the opposite of what a loyalty network should do.\n\n## Our Model: Free Listing, Paid Marketing\n\nInstead of charging for presence, we charge for **reach**:\n\n- **Free:** list your business, set your discount, receive organic One Pass members\n- **Paid:** run targeted campaigns to all One Pass members in your city or category\n\nThis way, a small bookshop in Lisbon can join for free and still get paying customers through the door. A restaurant that wants to fill tables on a quiet Tuesday can pay to reach more members.\n\n## What Free Onboarding Includes\n\n- Full business profile with logo, gallery, and hours\n- Discount configuration (5–20%)\n- Customer reviews and messaging\n- Bookings (if you offer them)\n- Analytics dashboard\n- QR redemption at no cost\n\n## What Costs Money\n\n- **Email blasts** to all members beyond your own past customers\n- **Featured placement** in the directory\n- **Premium analytics** (advanced segmentation and forecasting)\n\n## The Result\n\nSince launch, we've onboarded **hundreds of businesses across 10+ European cities** — most of them independents. The free tier is what makes the network valuable: the more diverse the businesses, the more valuable the pass.\n\n---\n\n*Join the network for free at [onepass.app/business-onboarding](https://onepass.app/business-onboarding).*	business	Marco Silvestri	\N	https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=1200	published	2026-07-05 09:00:00	{business,onboarding,free,pricing,model}	4	t
6a5e080f9e4f1493062edd79	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	Behind the Design: Building a Premium Feel Without the Pretension	behind-the-design	Our design team shares the principles behind One Pass's visual identity — deep indigo, gold accents, and a focus on clarity over flash.	# Behind the Design of One Pass\n\nWhen people hear "premium loyalty platform," they expect either sterile luxury (gold, marble, serif fonts) or aggressive startup energy (neon, gradients, bold sans). We chose neither.\n\n## Our Three Principles\n\n### 1. Premium Without Pretension\n\nWe use deep indigo as our primary colour — it's confident without shouting. Gold accents appear only where they mean something: premium badges, savings milestones, featured offers. When everything is gold, nothing is.\n\n### 2. Clarity Over Decoration\n\nEvery screen should answer one question: *what can I do here?* We removed animations that exist only to impress, kept transitions that help you understand where you are in a flow.\n\n### 3. Respect for the Reader\n\nText is a feature. We chose Plus Jakarta Sans for body text because it reads cleanly at small sizes. Sora for headings because it has personality without being quirky. Playfair Display appears sparingly — on the cover of PDFs and the editorial moments.\n\n## The QR Wallet\n\nThe most-used screen in the app is the QR Wallet. We designed it to be:\n\n- **Instantly scannable** — high contrast, centered, no clutter\n- **Calm** — no countdown timers, no urgency tricks\n- **Informative** — your membership status is visible but not boastful\n\n## Dark Mode\n\nDark mode isn't just inverted colours. We retuned every surface — indigo darkens to a near-black with blue undertones, gold becomes warmer, borders become subtle. It's the version many of our team members use full-time.\n\n## Accessibility\n\n- All text passes **WCAG AA contrast** at minimum\n- Tap targets are **44×44px minimum** on mobile (iOS HIG standard)\n- Every interactive element has a visible focus state\n- We test with screen readers on every release\n\n---\n\n*Design is how it works. That's the principle we keep coming back to.*	company	One Pass Design Team	\N	https://images.unsplash.com/photo-1545239351-ef35f43d514b?w=1200	published	2026-07-12 13:00:00	{design,brand,ui,accessibility,identity}	4	f
6a5e080f9e4f1493062edd76	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	How One Pass Uses AI to Recommend the Right Business for You	ai-recommendations-explained	A look under the hood at the recommendation engine that matches members with businesses they'll love — without invading their privacy.	# How One Pass Recommends Businesses\n\nEvery time you open the One Pass app, you see a personalised list of businesses and offers. Here's how that works — and how we protect your privacy while doing it.\n\n## The Signals We Use\n\nOur recommendation engine considers:\n\n- **Your saved favorites** — the categories and businesses you've bookmarked\n- **Your redemption history** — where you've actually used your discount\n- **Your location** — businesses near you are weighted higher (only when you opt in)\n- **Your search queries** — what you've looked for in the Directory\n- **Time of day** — lunch spots at noon, dinner spots in the evening\n\n## What We Don't Use\n\nWe deliberately do **not** use:\n\n- Your income or spending power\n- Sensitive personal data (health, religion, sexual orientation)\n- Data from third-party brokers\n- Your contacts or social graph\n\n## Explainability\n\nEvery recommendation comes with a **"Why am I seeing this?"** label. You'll see something like:\n\n> *Recommended because you saved 3 Italian restaurants and it's near your usual area.*\n\nIf a recommendation feels off, you can dismiss it and we'll learn from the feedback.\n\n## Privacy Controls\n\nYou're in charge:\n\n- **Disable location** in Settings → Privacy — we'll show global recommendations instead\n- **Clear your recommendation history** at any time\n- **Export your data** under GDPR — all of it, in a portable format\n\n## The Model\n\nOur model is a hybrid of collaborative filtering and content-based ranking, retrained weekly. We don't use third-party APIs for personal data — everything runs on our own infrastructure.\n\n---\n\n*Good recommendations respect your boundaries. That's our principle.*	technology	One Pass Engineering	\N	https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1200	published	2026-07-08 08:00:00	{ai,recommendations,privacy,technology,machine-learning}	5	f
6a5e080f9e4f1493062edd75	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	5 Ways One Pass Saves You Money on Dining Out	save-money-dining-out	Practical tips for using your One Pass membership to cut your restaurant bill by up to 20%, every time you eat out.	# 5 Ways One Pass Saves You on Dining Out\n\nEating out is one of life's great pleasures — but it adds up. Here are five ways your One Pass membership turns every meal into a saving.\n\n## 1. Always Check the Directory First\n\nBefore booking a table, search the **Directory** for participating restaurants in your city. You'll find everything from trattorias to sushi bars offering 10–18% off.\n\n> **Pro tip:** Save your favourite restaurants as favorites so you get notified when they post new offers.\n\n## 2. Flash Offers and Limited-Time Deals\n\nPremium members get access to **flash offers** — short-term discounts that businesses use to fill tables on quiet nights. These can go as high as 20% off and often include extras like a free dessert or glass of wine.\n\n## 3. Stack with Lunch Menus\n\nMany One Pass restaurants offer set lunch menus at already-reduced prices. Your discount applies on top — so a €12 lunch can become €10 with your 15% off.\n\n## 4. Bring Friends, Share the Saving\n\nPremium members receive **gift credits**. Use them to treat a friend to a discounted meal — they don't need their own membership for that visit.\n\n## 5. Track Your Savings\n\nOpen the **Savings Tracker** in your dashboard to see how much you've saved over time. Watching the number grow is surprisingly motivating — members who track their savings eat out 20% more often at participating venues.\n\n---\n\n*Bon appétit — and bon savings. Open your QR Wallet next time the bill arrives.*	lifestyle	Sophie Bauer	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c0?w=1200	published	2026-07-10 10:00:00	{dining,restaurants,savings,tips,lifestyle}	3	f
6a5e080f9e4f1493062edd78	2026-07-20 11:35:43.598	2026-07-20 11:35:43.598	\N	Introducing Gift Credits: Share Your Savings with Friends	introducing-gift-credits	Premium members can now gift discount credits to friends — no membership required on the recipient's side. Here's how it works.	# Introducing Gift Credits\n\nToday we're launching **Gift Credits** — a new way for Premium members to share their One Pass benefits with friends and family.\n\n## How It Works\n\n1. Go to **Gifts** in your dashboard\n2. Choose a credit amount (€5, €10, €20, or custom)\n3. Enter your friend's email\n4. They receive a link to claim their credit\n5. When they visit a participating business, they show their QR code and the discount applies — no membership needed\n\n## Why We Built This\n\nOur members told us they wanted to introduce friends to One Pass without pressuring them to sign up. Gift credits are a gentle invitation: your friend gets a real discount at a real business, and if they like it, they can join later.\n\n## What Recipients Get\n\n- A personal QR code, just like a member\n- Access to the full business directory\n- The same discount percentage you'd get as a premium member\n- No account, no commitment, no spam\n\n## What Happens When Credits Run Out\n\nWhen the gifted credits are used up, the recipient can:\n\n- **Ignore it** — nothing happens, no nagging\n- **Join One Pass** — their QR code becomes a full member code\n- **Receive more gifts** — from you or anyone else\n\n## Limits\n\n- Premium members can gift up to **€100 per month** in credits\n- Credits expire 90 days after issue\n- One recipient can hold up to €200 in credits at a time\n\n## Try It Today\n\nOpen the **Gifts** tab and send your first credit. It takes less than a minute.\n\n---\n\n*Sharing savings is the best kind of gift. Try Gift Credits today.*	product	One Pass Team	\N	https://images.unsplash.com/photo-1513885535751-94b5769d0b1e?w=1200	published	2026-07-18 11:00:00	{gift,credits,premium,feature,launch}	3	t
6a54e5aae319e3bcded110ae	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	The Ultimate Guide to Maximizing Your Savings	maximizing-your-savings	Tips and strategies to get the most out of your Anerium Premium membership, from deal stacking to seasonal savings.	# The Ultimate Guide to Maximizing Your Savings\n\nYour Anerium Premium membership unlocks exclusive discounts everywhere. Here's how to maximize your savings.\n\n## Stack Your Discounts\n\nCombine Anerium discounts with seasonal sales for maximum savings.\n\n## Use the AI Assistant\n\nOur AI assistant finds the best deals near you based on your preferences.\n\n## Watch for Flash Deals\n\nBusinesses offer limited-time flash deals exclusively for Anerium members.\n\n## Track Your Savings\n\nUse the savings tracker to see how much you've saved over time.\n\n## Refer Friends\n\nEarn rewards by referring friends and family to Anerium.	lifestyle	ANERIUM Team	\N	\N	published	2026-06-10 00:00:00	{lifestyle,savings,tips,premium}	7	f
6a54e5aae319e3bcded110a9	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	How Anerium is Reshaping the $200B Loyalty Market	reshaping-loyalty-market	A deep dive into how a single QR code is replacing fragmented loyalty programs worldwide and what it means for businesses and consumers.	# How Anerium is Reshaping the $200B Loyalty Market\n\nThe global loyalty market is worth over $200 billion, yet it's fragmented, outdated, and frustrating for both businesses and consumers. Anerium One Pass is changing that.\n\n## The Problem with Traditional Loyalty\n\nConsumers carry dozens of loyalty cards they never use. Businesses pay exorbitant fees for white-label apps that nobody downloads. The entire system is broken.\n\n## One Pass, Infinite Possibilities\n\nWith Anerium, a single digital pass replaces every loyalty card. Businesses get instant access to a global member base. Consumers get one app, one pass, exclusive discounts everywhere.\n\n## What This Means for the Future\n\nThe loyalty industry is at an inflection point. Those who adapt will thrive. Those who cling to the old model will be left behind.	business	ANERIUM Team	\N	\N	published	2026-07-08 00:00:00	{loyalty,market,business,innovation}	8	t
6a54e5aae319e3bcded110ab	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	Behind the Scenes: Building a Global QR System	building-global-qr-system	A technical look at how we built a cryptographic one-time-use QR token system that handles millions of scans securely.	# Behind the Scenes: Building a Global QR System\n\nBuilding a QR code system that handles millions of scans securely is no small feat. Here's how we did it.\n\n## Cryptographic Tokens\n\nEach QR code contains a cryptographic one-time-use token that can't be duplicated or replayed.\n\n## Real-Time Validation\n\nWhen a QR code is scanned, our backend validates it in under 100ms, anywhere in the world.\n\n## Offline Mode\n\nFor areas with poor connectivity, we've built an offline validation system that syncs when back online.\n\n## Fraud Prevention\n\nOur system detects suspicious patterns and blocks abuse before it happens.	technology	ANERIUM Team	\N	\N	published	2026-06-28 00:00:00	{technology,qr,security,architecture}	10	f
6a54e5aae319e3bcded110ad	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	Anerium Hits 480K Members — Here's What's Next	480k-members-whats-next	We just crossed a major milestone. Here's a look at what we've accomplished and what's coming in the next year.	# Anerium Hits 480K Members — Here's What's Next\n\nWe're thrilled to announce that Anerium One Pass has crossed 480,000 members worldwide.\n\n## A Year of Growth\n\nIn the past year, we've expanded to 12 countries and partnered with over 5,000 businesses.\n\n## What's Coming\n\n- New AI-powered features\n- Expanded business tools\n- More countries and cities\n- Enhanced mobile experience\n\n## Thank You\n\nNone of this would be possible without our amazing community of members and business partners.	company	ANERIUM Team	\N	\N	published	2026-06-15 00:00:00	{company,milestone,growth}	4	f
6a54e5aae319e3bcded110aa	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	5 Ways AI Powers Your Anerium Experience	ai-powers-anerium	From personalized deal recommendations to fraud detection, here's how AI works behind the scenes to make your experience better.	# 5 Ways AI Powers Your Anerium Experience\n\nArtificial intelligence is at the heart of the Anerium platform. Here are five ways it enhances your experience.\n\n## 1. Personalized Recommendations\n\nOur AI learns your preferences and suggests deals you'll actually love.\n\n## 2. Fraud Detection\n\nEvery QR scan is analyzed in real-time to prevent abuse and protect businesses.\n\n## 3. Smart Savings\n\nThe AI assistant tracks your spending patterns and finds the best deals for you.\n\n## 4. Business Intelligence\n\nBusiness owners get AI-driven insights about their customers and performance.\n\n## 5. Natural Language Search\n\nJust ask for what you want — our AI understands natural language queries.	technology	ANERIUM Team	\N	\N	published	2026-07-03 00:00:00	{ai,technology,personalization}	6	f
6a54e5aae319e3bcded110ac	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	Why Local Businesses Love Anerium	why-local-businesses-love-anerium	Three business owners share how Anerium helped them attract new customers and build lasting loyalty in their communities.	# Why Local Businesses Love Anerium\n\nWe talked to three business owners about their experience with Anerium One Pass.\n\n## Maria's Cafe\n\nMaria runs a small cafe in Berlin. Since joining Anerium, she's seen a 30% increase in new customers.\n\n## Tony's Restaurant\n\nTony's family restaurant was struggling until they joined Anerium. Now they have a steady stream of loyal customers.\n\n## Sarah's Salon\n\nSarah's beauty salon uses Anerium's gift and loyalty features to keep customers coming back.	business	ANERIUM Team	\N	\N	published	2026-06-22 00:00:00	{business,testimonials,local}	5	f
6a54e5aae319e3bcded110b0	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	How We Designed the Anerium Membership Card	designing-membership-card	A design journey: how we created a digital membership card that feels premium, works everywhere, and stays secure.	# How We Designed the Anerium Membership Card\n\nThe Anerium membership card is more than just a digital pass — it's a symbol of premium access. Here's the story behind its design.\n\n## The Vision\n\nWe wanted a card that feels premium, works everywhere, and stays secure. No compromises.\n\n## The Design Process\n\nWe went through dozens of iterations, testing colors, layouts, and materials.\n\n## The Result\n\nA sleek digital card with a deep indigo and gold aesthetic that reflects the premium nature of the Anerium experience.\n\n## Security First\n\nThe card includes a cryptographic QR code that changes dynamically, ensuring it can't be copied or shared.	product	ANERIUM Team	\N	\N	published	2026-05-30 00:00:00	{product,design,membership}	6	f
6a54e5aae319e3bcded110af	2026-07-13 13:18:34.15	2026-07-13 13:18:34.15	\N	New Feature: AI Personal Assistant	ai-personal-assistant	Meet your new AI assistant that learns your preferences and recommends the best deals nearby. Here's how it works.	# New Feature: AI Personal Assistant\n\nWe're excited to introduce the Anerium AI Personal Assistant — your intelligent guide to the best deals and experiences.\n\n## How It Works\n\nThe AI assistant learns from your behavior — which businesses you visit, what categories you prefer, and when you're most active.\n\n## Key Features\n\n- Natural language search\n- Personalized deal recommendations\n- Savings tracking and insights\n- Trip planning with deals along your route\n\n## Getting Started\n\nOpen the AI Assistant from your dashboard and start chatting. It's that simple.	product	ANERIUM Team	\N	\N	published	2026-06-05 00:00:00	{product,ai,features}	5	f
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, business_id, business_name, user_id, user_name, user_email, user_phone, booking_type, booking_date, booking_time, party_size, notes, status, confirmed_at, cancelled_at, cancellation_reason, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: business_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_categories (id, name, description, icon, slug, parent_id, sort_order, is_active, created_date, updated_date, created_by) FROM stdin;
cat-001	Restaurants	\N	utensils	restaurants	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-002	Cafés	\N	coffee	cafes	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-003	Retail	\N	shopping-bag	retail	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-004	Beauty	\N	sparkles	beauty	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-005	Fitness	\N	dumbbell	fitness	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-006	Entertainment	\N	film	entertainment	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-007	Hotels	\N	bed	hotels	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
cat-008	Services	\N	briefcase	services	\N	\N	t	2026-08-13 09:22:10.060743+00	2026-08-13 09:22:10.060743+00	\N
\.


--
-- Data for Name: business_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_documents (id, created_date, updated_date, created_by, business_id, business_name, document_type, file_url, file_name, status, expiry_date, uploaded_by_id, uploaded_by_name, verified_by_id, verified_date, rejection_reason, description) FROM stdin;
\.


--
-- Data for Name: business_email_blasts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_email_blasts (id, created_date, updated_date, created_by, business_id, business_name, business_category, scope, target_country, target_city, target_area, subject, body, audience_count, price, currency, status, checkout_session_id, payment_id, review_notes, reviewed_by_id, reviewed_at, sent_count, failed_count, error_message) FROM stdin;
\.


--
-- Data for Name: business_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_locations (id, created_date, updated_date, created_by, business_id, business_name, name, address, city, country, postal_code, latitude, longitude, phone, email, business_hours, is_primary, is_active, description) FROM stdin;
6a538331fb9a6fade8730d6b	2026-07-12 12:06:09.391	2026-07-12 12:06:09.391	listrakft@gmail.com	\N	TechRepair Pro	North Branch	789 North Street	Berlin	Germany	10115	\N	\N	+49 30 5551234	\N	\N	f	t	\N
6a537cc55dc936bee1669902	2026-07-12 11:38:45.517	2026-07-12 12:05:50.388	listrakft@gmail.com	\N	TechRepair Pro	Downtown Branch	456 Downtown Ave	Berlin	Germany	10178	\N	\N	+49 30 9876543	\N	\N	f	t	\N
6a535fc622a7f0a90f9ae5ad	2026-07-12 09:35:02.288	2026-07-12 11:38:28.926	listrakft@gmail.com	\N	TechRepair Pro	Main Branch	123 Main Street	Berlin	Germany	10115	\N	\N	+49 30 1234567	\N	\N	f	t	\N
6a535f66c3eec6559ff3b127	2026-07-12 09:33:26.14	2026-07-12 09:33:26.14	ai_generated	\N	Azure Wellness Spa	Azure Wellness Spa - Bondi	5 Campbell Parade, Bondi Beach	Sydney	Australia	2026	-33.891475	151.276684	+61 2 9365 2147	bookings@azurewellness.au	\N	f	t	\N
6a535f66c3eec6559ff3b126	2026-07-12 09:33:26.131	2026-07-12 09:33:26.131	ai_generated	\N	Thames Cycle & Coffee	Thames Cycle & Coffee - Riverside	Unit 4, Riverside Walk, 21 Albert Bridge Road	London	United Kingdom	SW11 4QA	51.4816	-0.1486	+44 20 7946 0958	hello@thamescycle.co.uk	\N	f	f	\N
6a535f66c3eec6559ff3b125	2026-07-12 09:33:26.123	2026-07-12 09:33:26.123	ai_generated	\N	Oak & Ember Bistro	Oak & Ember - Downtown	1423 Market St	San Francisco	USA	94103	37.773972	-122.431297	+1-415-555-0134	info@oakandember.com	\N	t	t	\N
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.businesses (id, created_date, updated_date, created_by, name, owner_id, description, category, website, logo_url, is_active, is_verified, business_email, business_phone) FROM stdin;
biz-004	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	Zen Spa & Wellness	\N	Luxury spa offering massages, facials, and wellness treatments. Premium members get 15% off all services.	Beauty	https://zenspa.com	\N	t	t	book@zenspa.com	+34914234567
biz-005	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	FitZone Gym	\N	Modern fitness center with group classes, personal training, and state-of-the-art equipment. Premium members get 20% off monthly membership.	Fitness	https://fitzone.com	\N	t	t	join@fitzone.com	+34915234567
biz-006	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	CineLux Theater	\N	Premium cinema with reclining seats and 4K projection. Premium members get 2-for-1 tickets on weekdays.	Entertainment	https://cinelux.com	\N	t	t	info@cinelux.com	+34916234567
biz-007	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	Grand Plaza Hotel	\N	4-star hotel in the city center with rooftop pool and spa. Premium members get 15% off room rates.	Hotels	https://grandplaza.com	\N	t	t	reservations@grandplaza.com	+34917234567
biz-008	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	Sakura Sushi	\N	Japanese restaurant with fresh sushi and omakase menus. Premium members get 10% off all orders.	Restaurants	https://sakurasushi.com	\N	t	t	contact@sakurasushi.com	+34918234567
biz-009	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	TechHub Electronics	\N	Electronics retailer with the latest gadgets and accessories. Premium members get 5% off all products.	Retail	https://techhub.com	\N	t	t	support@techhub.com	+34919234567
biz-010	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	Sunset Nail Bar	\N	Trendy nail salon offering manicures, pedicures, and nail art. Premium members get 15% off all services.	Beauty	https://sunsetnails.com	\N	t	t	book@sunsetnails.com	+34920234567
biz-001	2026-08-13 09:22:10.059	2026-08-13 09:22:10.059	\N	La Bella Tavola	cmsr5i0mx0000p4398i3bsvp2	Authentic Italian restaurant serving handmade pasta and wood-fired pizza. Premium members get 15% off all dine-in orders.	Restaurants	https://labelle.com	\N	t	t	contact@labelle.com	+34911234567
\.


--
-- Data for Name: campaign_audience; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_audience (id, created_date, updated_date, created_by, campaign_id, campaign_title, user_id, user_name, status, sent_at, delivered_at, read_at, responded_at, description) FROM stdin;
\.


--
-- Data for Name: campaign_audiences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_audiences (id, description, campaign_id, campaign_title, user_id, user_name, status, sent_at, delivered_at, read_at, responded_at, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: campaign_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaign_messages (id, created_date, updated_date, created_by, campaign_id, campaign_title, channel, subject, body, scheduled_at, sent_at, status, recipient_count, open_count, click_count) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.campaigns (id, created_date, updated_date, created_by, business_id, business_name, title, description, type, status, channels, message_subject, message_body, start_date, end_date, scheduled_at, sent_at, target_audience, target_city, audience_filters, total_recipients, delivered_count, opened_count, clicked_count, conversion_count, coupon_id, gift_campaign_id, image_url, opt_in_only) FROM stdin;
6a5398d6175d2641a575f2f7	2026-07-12 13:38:30.405	2026-07-12 13:38:30.405	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test (Copy)	\N	coupon	draft	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	\N	\N	local	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a5398d6175d2641a575f2b4	2026-07-12 13:38:30.257	2026-07-12 13:38:30.257	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test	\N	loyalty	scheduled	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	2026-07-15 10:00:00	\N	specific	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a5398d6175d2641a575f293	2026-07-12 13:38:30.203	2026-07-12 13:38:30.203	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test (Copy)	\N	gift	draft	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	\N	\N	free	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a5398d6175d2641a575f279	2026-07-12 13:38:30.143	2026-07-12 13:38:30.143	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test	\N	announcement	scheduled	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	2026-07-15 10:00:00	\N	premium	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a5398d6175d2641a575f26c	2026-07-12 13:38:30.09	2026-07-12 13:38:30.09	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test (Copy)	\N	promotion	draft	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	\N	\N	all	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a527588f4e29adb8dde5137	2026-07-11 16:55:36.211	2026-07-11 16:55:36.211	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test (Copy)	\N	promotion	draft	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	\N	\N	all	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
6a527582032c1124bc7660f2	2026-07-11 16:55:30.611	2026-07-11 16:55:43.008	listrakft@gmail.com	\N	Bella Italia Ristorante	Summer Promo Test	\N	promotion	scheduled	{push,email}	Summer 15% Off!	Enjoy exclusive summer discounts at Bella Italia!	\N	\N	2026-07-15 10:00:00	\N	all	\N	{"opted_in_only": true, "membership_type": "all"}	0	0	0	0	0	\N	\N	\N	t
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_messages (id, created_date, updated_date, created_by, conversation_id, business_id, business_name, user_id, user_name, business_owner_id, sender_type, sender_id, sender_name, content, is_read, read_at) FROM stdin;
a87b4bdf-4eb3-44c5-812c-0137ed685045	2026-08-13 09:31:37.737	2026-08-13 09:31:37.737	\N	4883eec6-5c30-48e1-84e7-e91d94c6e187	\N	\N	cmsr5i0mx0000p4398i3bsvp2	info@anerium.com	\N	customer	cmsr5i0mx0000p4398i3bsvp2	info@anerium.com	E2E test message	t	2026-08-13 15:55:49.201
c6c32d4d-5942-46ae-b4d0-c90f25e367f3	2026-08-13 09:21:38.411	2026-08-13 09:21:38.411	\N	ai-cmsr5i0mx0000p4398i3bsvp2	\N	\N	cmsr5i0mx0000p4398i3bsvp2	admin@anerium.com	\N	assistant	ai-concierge	ANERIUM AI	Hi there! 🌟 ANERIUM OnePass is a fantastic membership platform that offers you discounts ranging from 5% to 20% at thousands of participating businesses worldwide. This includes a wide variety of categories like restaurants, cafés, retail, beauty, fitness, entertainment, hotels, and more!\n\nBy signing up for a free membership, you can start enjoying these discounts right away. All you need to do is browse through our participating businesses, find one that catches your eye, and present your OnePass membership when you make a purchase to unlock your savings.\n\nIt’s a great way to save money while enjoying your favorite places! If you have any specific interests or categories you’d like to explore, I can help you discover some offers tailored to your preferences. 😊	t	2026-08-13 15:55:56.023
07a2e7fc-d614-45ec-9a1c-08982b996cb0	2026-08-13 09:30:53.326	2026-08-13 09:30:53.326	\N	ai-cmsr5i0mx0000p4398i3bsvp2	\N	\N	cmsr5i0mx0000p4398i3bsvp2	info@anerium.com	\N	assistant	ai-concierge	ANERIUM AI	ANERIUM OnePass is a fantastic membership platform that gives you access to exclusive discounts ranging from 5% to 20% at thousands of participating businesses worldwide! 🌍 Whether you’re looking for a great meal at a restaurant, a treat from a café, shopping at retail stores, pampering yourself at beauty salons, or even booking a hotel, OnePass has you covered. \n\nAs a member, you can save money while enjoying your favorite activities and exploring new ones. Plus, it’s free to join! You can also earn loyalty points as you use the service, which can lead to even more savings. If you have any specific interests or places you love, I can help you discover participating businesses and offers tailored just for you!	t	2026-08-13 15:55:56.023
44e5c9ea-0483-4df4-b14b-0b12867bdb29	2026-08-13 09:32:45.632	2026-08-13 09:32:45.632	\N	ai-cmsr5i0mx0000p4398i3bsvp2	\N	\N	cmsr5i0mx0000p4398i3bsvp2	info@anerium.com	\N	assistant	ai-concierge	ANERIUM AI	Sure! ANERIUM OnePass is a loyalty platform that offers members exclusive discounts ranging from 5% to 20% at thousands of participating businesses worldwide. These businesses span across various categories, including restaurants, cafés, retail, beauty, fitness, entertainment, hotels, and more. \n\nWhat makes ANERIUM OnePass unique is its versatility and global reach, allowing you to save money while enjoying a wide array of services and experiences. With a free membership, you can easily access these offers without any hidden fees, making it budget-friendly.\n\nAdditionally, the platform keeps growing, constantly adding new partners to enhance your savings potential. Plus, you can accumulate loyalty points with your purchases, which can lead to even more rewards down the line. It's a great way to explore your city and beyond while enjoying discounts along the way! If you have any specific questions or want to know more about participating businesses, just let me know!	t	2026-08-13 15:55:56.023
528a8eeb-ed8a-4fc1-b39c-97ce6cad30a1	2026-08-13 09:46:58.348	2026-08-13 09:46:58.348	\N	ai-cmsr5i0mx0000p4398i3bsvp2	\N	\N	cmsr5i0mx0000p4398i3bsvp2	info@anerium.com	\N	assistant	ai-concierge	ANERIUM AI	Hi there! It looks like you’re testing things out. How can I assist you today? Whether you’re looking for discounts, business recommendations, or have questions about your membership, I’m here to help! 😊	t	2026-08-13 15:55:56.023
\.


--
-- Data for Name: commission_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commission_payments (id, partner_id, partner_name, partner_email, period, gross_amount, commission_rate, net_amount, currency, status, payment_method, payment_date, transaction_reference, referral_count, breakdown, notes, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: compliance_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_requests (id, created_date, updated_date, created_by, user_id, user_name, user_email, request_type, status, description, consent_type, consent_value, processed_by_id, processed_by_name, processed_at, export_url, deletion_scheduled_at, retention_category, retention_days, resolution_notes) FROM stdin;
\.


--
-- Data for Name: config_change_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_change_logs (id, created_date, updated_date, created_by, entity_type, entity_id, entity_key, action, previous_value, new_value, changed_by_id, changed_by_name, change_reason, is_critical, description) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, created_date, updated_date, created_by, business_id, business_name, code, title, description, discount_percentage, valid_from, valid_to, usage_limit, used_count, status, premium_only) FROM stdin;
\.


--
-- Data for Name: crm_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crm_records (id, created_date, updated_date, created_by, business_id, business_name, user_id, customer_name, vip_flag, tags, lifecycle_status, marketing_consent, internal_notes, follow_up_tasks, custom_fields, preferred_contact_method, last_contacted_date, description) FROM stdin;
6a5398d6175d2641a575f2f8	2026-07-12 13:38:30.405	2026-07-12 13:38:30.405	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	churned	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	email	\N	\N
6a5398d6175d2641a575f2ea	2026-07-12 13:38:30.377	2026-07-12 13:38:30.377	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	at_risk	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	none	\N	\N
6a5398d6175d2641a575f2d1	2026-07-12 13:38:30.332	2026-07-12 13:38:30.332	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	active	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	push	\N	\N
6a5398d6175d2641a575f2ae	2026-07-12 13:38:30.251	2026-07-12 13:38:30.251	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	new	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	sms	\N	\N
6a5398d6175d2641a575f289	2026-07-12 13:38:30.163	2026-07-12 13:38:30.163	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	vip	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	email	\N	\N
6a5281ee87c94bcf2d97c818	2026-07-11 17:48:30.621	2026-07-11 17:48:44.009	service+31c5bde9-d0c1-4521-8802-5c4023800578@no-reply.base44.com	\N	Bella Italia Ristorante	\N	Rojas Test	t	\N	vip	f	[{"id":"5995c996-f428-40e5-9d27-9cfe20316a2e","text":"Prefers afternoon appointments","author":"Rojs Gordons","date":"2026-07-11T17:48:43.863Z"}]	\N	\N	email	\N	\N
\.


--
-- Data for Name: developer_apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.developer_apps (id, created_date, updated_date, created_by, name, description, app_type, status, scopes, redirect_uri, api_key, api_secret_hash, webhook_url, webhook_secret, webhook_events, rate_limit_per_min, ip_whitelist, total_requests, requests_today, last_request_at, owner_name) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, created_date, updated_date, created_by, user_id, device_type, device_id, device_name, os_version, app_version, push_token, last_seen, ip_address, is_active, is_trusted, description) FROM stdin;
\.


--
-- Data for Name: discounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discounts (id, created_date, updated_date, created_by, business_id, business_name, title, description, percentage, category, tags, image_url, min_purchase_amount, max_discount_amount, valid_from, valid_to, usage_limit, used_count, is_active, premium_only, is_featured, is_limited_time, terms_conditions, eligible_branch_ids, redemption_requirements, view_count, sort_order) FROM stdin;
6a5e020b0bb7b81f7e67f6c7	2026-07-20 11:10:03.025	2026-07-20 11:10:03.025	\N	\N	The Crown Pub	15% Off Dinner Menu	Enjoy 15% off the full dinner menu. Show your One Pass QR code at the table.	8	restaurants	{dinner,weekday,all-members}	https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	46	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	187	0
6a5e020b0bb7b81f7e67f6c9	2026-07-20 11:10:03.025	2026-07-20 11:10:03.025	\N	\N	Green Bowl Salads	Buy 2 Get 1 Free Pastries	Buy two pastries, get one free for premium members. Fresh baked daily.	10	cafes	{pastries,bakery,premium}	https://images.unsplash.com/photo-1490645935967-10de6bafe61d?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	25	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	366	0
6a5e020b0bb7b81f7e67f6c8	2026-07-20 11:10:03.025	2026-07-20 11:10:03.025	\N	\N	El Patio Andaluz	Free Dessert with Main Course	Complimentary dessert with any main course for One Pass premium members.	15	restaurants	{dessert,lunch,dinner}	https://images.unsplash.com/photo-1504083742429-1b8b66c86c3e?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	30	t	t	t	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	87	0
6a5e020b0bb7b81f7e67f6af	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	LuxNail Bar	Free Lash Upgrade	Free lash upgrade with any lash extension booking for premium members.	12	beauty	{lashes,premium,upgrade}	https://images.unsplash.com/photo-1607779097040-26e80aa4cd6f?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	44	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	348	0
6a5e020b0bb7b81f7e67f6ad	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Pilates Core Studio	Free Personal Training Session	One complimentary PT session for new premium members. Book at reception.	15	fitness	{personal-training,premium,free}	https://images.unsplash.com/photo-1591291621164-2c6367723315?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	44	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	336	0
6a5e020b0bb7b81f7e67f6b6	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Tapas & Co	Free Dessert with Main Course	Complimentary dessert with any main course for One Pass premium members.	10	restaurants	{dessert,lunch,dinner}	https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	15	t	t	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	251	0
6a5e020b0bb7b81f7e67f6b5	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Burger Republic	15% Off Dinner Menu	Enjoy 15% off the full dinner menu. Show your One Pass QR code at the table.	12	restaurants	{dinner,weekday,all-members}	https://images.unsplash.com/photo-1550547660-d9450f8108a9?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	20	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	85	0
6a5e020b0bb7b81f7e67f6b2	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Grand Plaza Hotel	18% Off Room Rates	18% off best available room rates. Includes breakfast and free WiFi.	18	hotels	{hotel,rooms,breakfast}	https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	42	t	t	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	212	0
6a5e020b0bb7b81f7e67f6ac	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	BookNook Bookstore	15% Off Full Collection	15% off all items in store. Show your One Pass QR code at checkout. Excludes sale items.	12	retail	{shopping,fashion,all-members}	https://images.unsplash.com/photo-1521587760476-6c12a4b050da?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	1	t	t	t	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	241	0
6a5e020b0bb7b81f7e67f6ae	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Vinyl & Vino	12% Off All Tickets	12% discount on all movie tickets and concessions. Show QR at the box office.	10	entertainment	{movies,tickets,daily}	https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	38	t	t	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	259	0
6a5e020b0bb7b81f7e67f6b4	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Savoy Grand Hotel	18% Off Room Rates	18% off best available room rates. Includes breakfast and free WiFi.	20	hotels	{hotel,rooms,breakfast}	https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	13	t	t	t	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	107	0
6a5e020b0bb7b81f7e67f6b0	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Cacao Craft Chocolate	15% Off Full Collection	15% off all items in store. Show your One Pass QR code at checkout. Excludes sale items.	12	retail	{shopping,fashion,all-members}	https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	24	t	t	f	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	435	0
6a5e020b0bb7b81f7e67f6b1	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Barbar Barbershop	Free Lash Upgrade	Free lash upgrade with any lash extension booking for premium members.	15	beauty	{lashes,premium,upgrade}	https://images.unsplash.com/photo-1522337660859-02fbefca4702?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	41	t	f	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	418	0
6a5e020b0bb7b81f7e67f6b3	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Riverside Boutique Hotel	Free Room Upgrade	Complimentary room upgrade for premium members, subject to availability.	15	hotels	{upgrade,premium,hotel}	https://images.unsplash.com/photo-1455587734955-081b22074882?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	6	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	300	0
6a5e020b0bb7b81f7e67f6c0	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Moda Fashion House	15% Off Full Collection	15% off all items in store. Show your One Pass QR code at checkout. Excludes sale items.	15	retail	{shopping,fashion,all-members}	https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	23	t	t	t	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	161	0
6a5e020b0bb7b81f7e67f6ba	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Cineworld Premium	12% Off All Tickets	12% discount on all movie tickets and concessions. Show QR at the box office.	12	entertainment	{movies,tickets,daily}	https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	47	t	t	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	314	0
6a5e020b0bb7b81f7e67f6bf	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	The Daily Grind	Buy 2 Get 1 Free Pastries	Buy two pastries, get one free for premium members. Fresh baked daily.	10	cafes	{pastries,bakery,premium}	https://images.unsplash.com/photo-1453614512568-c4024d13c247?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	10	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	139	0
6a5e020b0bb7b81f7e67f6c6	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Le Petit Bistro	Weekend Brunch Special	15% off weekend brunch including bottomless drinks. Reservation required.	10	restaurants	{brunch,weekend,drinks}	https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	17	t	t	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	456	0
6a5e020b0bb7b81f7e67f6c1	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Urban Threads	Members-Only Exclusive Drop	Early access to new arrivals plus 12% off for premium members only.	12	retail	{exclusive,new-arrivals,premium}	https://images.unsplash.com/photo-1441985009460-9b6a8d3a1d4f?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	19	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	180	0
6a5e020b0bb7b81f7e67f6bb	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Riverside Bowling Alley	Free Game with 2 Games	Book two bowling games, get one free for premium members. Weekdays only.	15	entertainment	{bowling,games,weekday}	https://images.unsplash.com/photo-1519834782981-945e2390d3e7?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	8	t	f	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	472	0
6a5e020b0bb7b81f7e67f6c5	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Sakura Sushi House	Free Dessert with Main Course	Complimentary dessert with any main course for One Pass premium members.	12	restaurants	{dessert,lunch,dinner}	https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	16	t	f	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	88	0
6a5e020b0bb7b81f7e67f6bd	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	ClickPro Photography	Free Diagnostic Check	Complimentary diagnostic check for premium members with any service booking.	15	services	{diagnostic,premium,free}	https://images.unsplash.com/photo-1503454537195-1dcabb73e412?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	33	t	f	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	412	0
6a5e020b0bb7b81f7e67f6c3	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Serene Spa & Wellness	Free Lash Upgrade	Free lash upgrade with any lash extension booking for premium members.	18	beauty	{lashes,premium,upgrade}	https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	1	t	f	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	427	0
6a5e020b0bb7b81f7e67f6b7	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Wellness Dental Care	Free Diagnostic Check	Complimentary diagnostic check for premium members with any service booking.	15	services	{diagnostic,premium,free}	https://images.unsplash.com/photo-1588776813642-8e9071c6d2cf?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	15	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	459	0
6a5e020b0bb7b81f7e67f6bc	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Prime Auto Repair	15% Off All Services	15% discount on all repair services. Show your One Pass QR code on arrival.	10	services	{service,repair,daily}	https://images.unsplash.com/photo-1487754180451-c456f9c7e8e1?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	15	t	t	f	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	488	0
6a5e020b0bb7b81f7e67f6be	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Caffè Roma	10% Off All Beverages	10% discount on all coffees, teas, and smoothies. Show your QR code at checkout.	12	cafes	{coffee,daily,all-members}	https://images.unsplash.com/photo-1442975631115-c4f7b05b8a2c?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	7	t	t	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	195	0
6a5e020b0bb7b81f7e67f6c2	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Glow Beauty Lounge	15% Off All Treatments	15% discount on facials, manicures, and waxing. Book in advance and show QR code.	15	beauty	{facial,manicure,daily}	https://images.unsplash.com/photo-1521590832167-8b1c4b9f2d1b?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	4	t	t	t	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	272	0
6a5e020b0bb7b81f7e67f6c4	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Bella Vista Trattoria	15% Off Dinner Menu	Enjoy 15% off the full dinner menu. Show your One Pass QR code at the table.	15	restaurants	{dinner,weekday,all-members}	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	7	t	t	t	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	265	0
6a5e020b0bb7b81f7e67f6b9	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	Yoga Sunrise Studio	Free Personal Training Session	One complimentary PT session for new premium members. Book at reception.	15	fitness	{personal-training,premium,free}	https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	4	t	f	f	f	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	237	0
6a5e020b0bb7b81f7e67f6b8	2026-07-20 11:10:03.024	2026-07-20 11:10:03.024	\N	\N	FitLife Gym	20% Off Monthly Membership	20% off your monthly gym membership. First month free trial included.	20	fitness	{gym,membership,monthly}	https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800	0	\N	2026-07-20 00:00:00	2026-12-31 23:59:59	\N	49	t	t	f	t	Valid for One Pass members only. Cannot be combined with other offers. Subject to availability.	\N	{"Show One Pass QR code at checkout or booking"}	298	0
6a528dfd675d21caa7c4f63f	2026-07-11 18:39:57.923	2026-07-11 18:39:57.923	\N	\N	The Book Haven	Bestseller 15% Off	Get 15% off all bestseller lists and new arrivals.	15	retail	{books,bestseller,new}	\N	20	\N	2026-07-01 00:00:00	2026-09-30 23:59:59	\N	0	t	f	t	f	In-store purchases only. Excludes textbooks and special orders.	\N	{"Show QR code at checkout."}	54	1
6a528dfd675d21caa7c4f63c	2026-07-11 18:39:57.923	2026-07-11 18:39:57.923	\N	\N	Lumen Fitness Studio	First Class Free + 10% Off	Try your first class free and get 10% off any class pack.	10	fitness	{trial,new,classes}	\N	0	\N	2026-01-01 00:00:00	2026-12-31 23:59:59	\N	0	t	f	f	f	First-time visitors only. Class pack must be purchased same day as trial.	\N	{"Present QR code at front desk."}	45	2
6a528dfd675d21caa7c4f639	2026-07-11 18:39:57.923	2026-07-12 09:56:12.779	\N	\N	Urban Grind Coffee	Morning Brew 12% Off	Start your morning right with 12% off all coffee orders before 10am.	12	cafes	{morning,coffee,breakfast}	\N	3	\N	2026-07-01 00:00:00	2026-09-30 23:59:59	\N	0	t	f	t	f	Valid daily before 10am. All coffee drinks included.	\N	{"Show QR code before payment."}	238	1
6a528dfd675d21caa7c4f63a	2026-07-11 18:39:57.923	2026-07-12 12:40:29.473	\N	\N	Urban Grind Coffee	Flash: Buy 1 Get 20% Off 2nd	Limited time flash offer - buy any drink and get 20% off your second one!	20	cafes	{flash,summer,buy1get1}	\N	5	\N	2026-07-08 00:00:00	2026-07-14 23:59:59	\N	0	t	t	t	t	Both drinks must be same size. Valid all day. Limited to one redemption per customer per day.	\N	{"Present QR code at register before ordering."}	320	1
6a528dfd675d21caa7c4f63d	2026-07-11 18:39:57.923	2026-07-11 18:39:57.923	\N	\N	Glow Beauty Lounge	Premium Spa Day 20% Off	Treat yourself to a full spa day with 20% off all treatments.	20	beauty	{spa,premium,pamper}	\N	60	\N	2026-07-01 00:00:00	2026-07-20 23:59:59	\N	0	t	t	t	t	Booking required 48h in advance. Valid Monday-Thursday only. Treatments over 60min.	\N	{"Show QR code at appointment check-in."}	198	1
6a528dfd675d21caa7c4f63b	2026-07-11 18:39:57.923	2026-07-11 18:39:57.923	\N	\N	Lumen Fitness Studio	Summer Membership 18% Off	Get 18% off any monthly membership plan this summer.	18	fitness	{summer,membership,fitness}	\N	50	\N	2026-06-15 00:00:00	2026-08-31 23:59:59	\N	0	t	t	t	f	New members only. 3-month minimum commitment. Cannot be combined with trial passes.	\N	{"Show QR code at front desk during enrollment."}	67	1
6a528dfd675d21caa7c4f638	2026-07-11 18:39:57.923	2026-07-12 10:16:06.438	\N	\N	Bella Italia Ristorante	Lunch Express 10% Off	Quick lunch? Get 10% off all lunch menus Monday to Friday.	10	restaurants	{lunch,weekday,express}	\N	10	\N	2026-06-01 00:00:00	2026-12-31 23:59:59	\N	0	t	f	f	f	Valid Monday-Friday 11am-3pm. Dine-in or takeout.	\N	{"Show QR code at checkout."}	90	2
6a528dfd675d21caa7c4f63e	2026-07-11 18:39:57.923	2026-07-11 18:39:57.923	\N	\N	Glow Beauty Lounge	Manicure Tuesday 8% Off	Get 8% off all manicure services every Tuesday.	8	beauty	{manicure,tuesday,weekly}	\N	15	\N	2026-06-01 00:00:00	2026-12-31 23:59:59	\N	0	t	f	f	f	Valid Tuesdays only. Walk-ins welcome.	\N	{"Show QR code at check-in."}	76	2
6a528dfd675d21caa7c4f637	2026-07-11 18:39:57.922	2026-07-11 18:39:57.922	\N	\N	Bella Italia Ristorante	Weekend Dinner Special	Enjoy 15% off all dinner menus every weekend. Perfect for date night or family gatherings.	15	restaurants	{weekend,dinner,"date night"}	\N	25	\N	2026-07-01 00:00:00	2026-08-31 23:59:59	\N	0	t	t	t	f	Valid Friday-Sunday after 5pm. Dine-in only. Cannot be combined with other offers.	\N	{"Show your OnePass QR code to server before ordering."}	142	1
\.


--
-- Data for Name: disputes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disputes (id, user_id, user_name, business_id, business_name, business_owner_id, transaction_id, qr_code_id, reason, description, evidence_urls, status, business_response, business_responded_at, resolution_notes, refund_amount, refund_issued, sla_due_at, escalated_at, resolved_at, resolved_by_id, timeline, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: employee_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_schedules (id, created_date, updated_date, created_by, employee_id, employee_name, business_id, business_name, branch_id, branch_name, weekday, start_time, end_time, break_minutes, is_recurring, specific_date, clock_in_time, clock_out_time, status, notes) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, created_date, updated_date, created_by, business_id, business_name, user_id, full_name, email, phone, role, permissions, is_active, hired_date, branch_id, branch_name, description) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.favorites (id, created_date, updated_date, created_by, user_id, user_name, business_id, business_name, category, discount_id, discount_title, collection_name, notify_on_change, is_watched, description) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_flags (id, name, description, key, is_enabled, rollout_strategy, target_countries, target_user_groups, rollout_percentage, scheduled_activation_at, scheduled_deactivation_at, created_by_id, created_by_name, updated_by_id, updated_by_name, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: gift_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gift_campaigns (id, created_date, updated_date, created_by, business_id, business_name, title, description, gift_type, value, value_unit, trigger_type, audience_type, target_user_ids, segment_rules, milestone_metric, milestone_threshold, valid_from, valid_to, expiry_days, total_quantity, claimed_quantity, redeemed_quantity, per_customer_limit, points_reward, status, image_url, scheduled_at, sent_count) FROM stdin;
6a5280d216f99732e22700e4	2026-07-11 17:43:46.687	2026-07-12 09:46:37.265	\N	\N	Bella Italia Ristorante	Birthday 15% Off	Special birthday gift for loyal customers	discount	15	percentage	birthday	all	{}	\N	\N	\N	\N	\N	30	200	1	0	1	50	active	\N	\N	0
\.


--
-- Data for Name: gift_redemptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gift_redemptions (id, description, gift_campaign_id, gift_campaign_title, user_id, user_name, business_id, business_name, awarded_date, redeemed_date, expiry_date, status, redemption_code, gift_type_snapshot, gift_value_snapshot, gift_value_unit_snapshot, source, points_awarded, transaction_id, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, created_date, updated_date, created_by, user_id, user_name, business_id, business_name, payment_id, subscription_id, invoice_number, amount, currency, tax_rate, tax_amount, total_amount, billing_period, status, issue_date, due_date, paid_date, pdf_url, line_items, refund_amount, refunded_at, refund_reason, notes) FROM stdin;
\.


--
-- Data for Name: knowledge_bases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_bases (id, title, content, summary, category, subcategory, article_type, tags, is_published, is_featured, status, language, video_url, screenshots, sort_order, version, approved_by_id, approved_by_name, approved_at, translation_key, view_count, helpful_count, unhelpful_count, author_id, author_name, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: loyalty_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_points (id, created_date, updated_date, created_by, user_id, user_name, business_id, business_name, points, points_type, expiry_date) FROM stdin;
lp_4d615f0e-8084-44a8-add7-f6809a5a00d3	2026-08-08 17:18:50.244	2026-08-13 09:46:01.169	\N	test_cust_01	\N	\N	\N	50	\N	\N
lp_4d30cfc2-14f6-4f46-913b-3baad0754e8c	2026-08-06 08:26:30.822	2026-08-13 09:46:01.169	\N	test_cust_02	\N	\N	\N	100	\N	\N
lp_cbe60621-f02f-44cd-a962-c2442fdb9ca4	2026-08-05 19:30:54.54	2026-08-13 09:46:01.169	\N	test_cust_03	\N	\N	\N	100	\N	\N
lp_6b9308ca-ff71-4bcc-a1d9-a48726066181	2026-08-03 21:50:06.539	2026-08-13 09:46:01.169	\N	test_cust_04	\N	\N	\N	100	\N	\N
lp_296b6241-fd24-43ba-9d4e-dbb429d51292	2026-07-31 19:52:00.514	2026-08-13 09:46:01.169	\N	test_cust_05	\N	\N	\N	100	\N	\N
\.


--
-- Data for Name: loyalty_tiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loyalty_tiers (id, created_date, updated_date, created_by, business_id, business_name, level_name, min_points, max_points, color, icon, benefits, points_multiplier, discount_bonus, priority_support, free_monthly_gift, sort_order, is_active, description) FROM stdin;
6a5398d6175d2641a575f2aa	2026-07-12 13:38:30.229	2026-07-12 13:38:30.229	listrakft@gmail.com	\N	Bella Italia Ristorante	Bronze	0	499	#cd7f32	Award	{"[\\"5% bonus discount\\"","\\"Birthday gift\\"]"}	1	0	f	f	1	t	\N
6a5280d243f26548880ee30c	2026-07-11 17:43:46.789	2026-07-11 17:43:46.789	listrakft@gmail.com	\N	Bella Italia Ristorante	Bronze	0	499	#cd7f32	Award	{"[\\"5% bonus discount\\"","\\"Birthday gift\\"]"}	1	0	f	f	1	t	\N
\.


--
-- Data for Name: membership_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_plans (id, created_date, updated_date, created_by, name, description, plan_type, price, original_price, currency, billing_cycle, features, feature_entitlements, trial_days, is_promotional, is_active, is_archived, archived_at, sort_order, max_discount_percentage) FROM stdin;
cmsr5jbq80000p47lik7u2f0i	2026-08-13 06:43:22.017	2026-08-13 06:43:22.017	\N	Free Member	Basic membership with access to standard discounts	free	0	\N	EUR	monthly	{"Access to standard discounts",SavingsTracker,"Basic QR codes"}	\N	0	f	t	f	\N	0	\N
cmsr5jbqb0001p47l9vjung69	2026-08-13 06:43:22.02	2026-08-13 06:43:22.02	\N	Premium Member	Premium membership with exclusive discounts and features	premium	9.99	19.99	EUR	monthly	{"All standard discounts","Exclusive premium discounts","Advanced SavingsTracker analytics","Priority customer support","Unlimited QR codes","Early access to new discounts"}	\N	14	t	t	f	\N	1	80
6a6860b577442d6a186052f4	2026-07-28 07:56:37.723	2026-07-28 07:56:37.723	\N	Free	Browse and search businesses, read reviews, and save favorites. No QR discount code.	customer	0	\N	EUR	monthly	{"Browse business directory","Read & write reviews","Save favorites","Business search"}	\N	0	f	t	f	\N	0	0
6a527d04fc33763b53b4f348	2026-07-11 17:27:32.044	2026-07-11 17:27:32.044	\N	Premium Annual	Best value — 2 months free	customer	99.99	\N	EUR	annual	{"Unlimited discounts","Priority support","Digital pass","Exclusive offers","Early access"}	{"early_access": true, "max_discounts": "unlimited", "priority_support": true}	14	f	t	f	\N	2	20
6a527d04fc33763b53b4f349	2026-07-11 17:27:32.044	2026-07-11 17:27:32.044	\N	Business Starter	Perfect for small businesses getting started	business	29.99	\N	EUR	monthly	{"1 branch","QR codes","Basic analytics","Email support"}	{"max_branches": 1, "max_campaigns": 3, "max_employees": 5}	30	f	t	f	\N	3	15
6a527d04fc33763b53b4f34a	2026-07-11 17:27:32.044	2026-07-11 17:27:32.044	\N	Business Pro	For growing businesses with multiple locations	business	79.99	\N	EUR	monthly	{"5 branches","QR codes","Advanced analytics","Marketing tools","Priority support"}	{"max_branches": 5, "max_campaigns": 20, "max_employees": 25, "advanced_analytics": true}	30	f	t	f	\N	4	20
6a527d04fc33763b53b4f34b	2026-07-11 17:27:32.044	2026-07-22 08:40:32.707	\N	Summer Promo	Limited time promotional plan — 50% off Premium	customer	4.99	9.99	EUR	monthly	{"All Premium features at half price for 3 months"}	\N	0	t	t	f	\N	0	20
6a526563ff49602ea4c4bec1	2026-07-11 15:46:43.77	2026-07-11 15:46:43.77	\N	Premium Monthly	Full premium membership. Redeem 5%–20% discounts at all participating businesses.	\N	9.99	\N	EUR	monthly	{"5%–20% discounts at all businesses","Unlimited redemptions","Priority support","Transaction history","Early access to new features"}	\N	14	f	t	f	\N	2	20
6a526563ff49602ea4c4bec0	2026-07-11 15:46:43.77	2026-07-11 15:46:43.77	\N	Free	Basic membership with directory access. No discount redemptions.	\N	0	\N	EUR	monthly	{"Browse business directory","View business profiles","Read reviews","Save favorites"}	\N	0	f	t	f	\N	1	0
6a526563ff49602ea4c4bec2	2026-07-11 15:46:43.77	2026-07-11 15:46:43.77	\N	Premium Annual	Best value — full premium membership for a full year. 2 months free vs monthly.	\N	99.99	\N	EUR	annual	{"5%–20% discounts at all businesses","Unlimited redemptions","Priority support","Transaction history","Early access to new features","2 months free"}	\N	14	f	t	f	\N	3	20
\.


--
-- Data for Name: newsletter_subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.newsletter_subscribers (id, created_date, updated_date, created_by, email, name, source, is_active, subscribed_at, description) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, created_date, updated_date, created_by, name, key, channel, subject, body, variables, language, is_active, version, previous_body, previous_subject, previous_version, created_by_id, created_by_name, updated_by_id, updated_by_name) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, created_date, updated_date, created_by, user_id, title, message, description, type, priority, is_read, is_archived, action_url, action_label, channel, sent_at, read_at, clicked_at, image_url, business_id, business_name) FROM stdin;
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (id, description, user_id, phone_number, code_hash, delivery_method, expires_at, attempts, verified, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: outreach_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outreach_campaigns (id, created_date, updated_date, created_by, title, description, target_category, target_city, target_country, email_subject, email_body, recipients, status, total_recipients, sent_count, failed_count, response_count, sent_at, created_by_name) FROM stdin;
\.


--
-- Data for Name: partner_referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.partner_referrals (id, created_date, updated_date, created_by, partner_id, partner_name, partner_email, referral_code, referred_email, referred_name, referral_type, status, signed_up_date, converted_date, churned_date, commission_rate, monthly_commission, total_commission_earned, is_active, description) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, description, user_id, user_name, type, provider, provider_payment_method_id, last4, brand, expiry_month, expiry_year, is_default, is_active, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, created_date, updated_date, created_by, user_id, user_name, business_id, business_name, subscription_id, campaign_id, payment_method_id, amount, currency, payment_type, status, transaction_id, provider, provider_transaction_id, paid_at, failure_reason, refund_amount, refunded_at, description) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, created_date, updated_date, created_by, name, description, resource, action, is_active) FROM stdin;
cmsr5i0ng0008p4397icn7i7r	2026-08-13 06:42:21.004	2026-08-13 06:42:21.004	\N	discounts.view	\N	discounts	view	t
cmsr5i0ni0009p439u2a0f2a8	2026-08-13 06:42:21.007	2026-08-13 06:42:21.007	\N	discounts.create	\N	discounts	create	t
cmsr5i0nk000ap439uwaizdry	2026-08-13 06:42:21.008	2026-08-13 06:42:21.008	\N	discounts.edit	\N	discounts	edit	t
cmsr5i0nl000bp439nrzm0n0h	2026-08-13 06:42:21.01	2026-08-13 06:42:21.01	\N	discounts.delete	\N	discounts	delete	t
cmsr5i0nn000cp4397nr66f57	2026-08-13 06:42:21.011	2026-08-13 06:42:21.011	\N	campaigns.view	\N	campaigns	view	t
cmsr5i0no000dp43972qdtdow	2026-08-13 06:42:21.013	2026-08-13 06:42:21.013	\N	campaigns.create	\N	campaigns	create	t
cmsr5i0nq000ep439jfcc2pk3	2026-08-13 06:42:21.014	2026-08-13 06:42:21.014	\N	campaigns.edit	\N	campaigns	edit	t
cmsr5i0nr000fp439kboc5go0	2026-08-13 06:42:21.016	2026-08-13 06:42:21.016	\N	crm.view	\N	crm	view	t
cmsr5i0ns000gp439dfy9yfi9	2026-08-13 06:42:21.017	2026-08-13 06:42:21.017	\N	crm.edit	\N	crm	edit	t
cmsr5i0nu000hp439tbztjbr9	2026-08-13 06:42:21.018	2026-08-13 06:42:21.018	\N	reports.view	\N	reports	view	t
cmsr5i0nv000ip439c4a1swfj	2026-08-13 06:42:21.02	2026-08-13 06:42:21.02	\N	settings.edit	\N	settings	edit	t
\.


--
-- Data for Name: qr_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qr_codes (id, created_date, updated_date, created_by, user_id, user_name, code, qr_token, status, generated_date, activated_date, deactivated_date, expires_at, scan_count, last_scan_date, description) FROM stdin;
\.


--
-- Data for Name: review_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_replies (id, created_date, updated_date, created_by, review_id, business_id, business_name, author_name, author_id, content, is_business_reply, is_active, is_draft, edited_at, content_history) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, created_date, updated_date, created_by, business_id, business_name, rating, comment, customer_name, customer_id, branch_id, branch_name, employee_id, employee_name, transaction_id, resolution_status, is_verified, sentiment, tags, description) FROM stdin;
6a5e01f96f93620f30a5dc2e	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc37	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc3c	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc45	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc3f	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc41	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc34	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc39	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc3a	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc3d	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc32	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc2d	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc2f	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc35	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc2b	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc30	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc40	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a539528554472889c0230c1	2026-07-12 13:22:48.74	2026-07-12 13:22:48.74	\N	biz-004	Sakura Sushi	4	Great experience! The staff was friendly and professional. I really enjoyed my visit and will definitely come back.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	\N	\N	\N
6a5e01f96f93620f30a5dc3b	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc44	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc46	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc36	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc3e	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc43	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc38	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc31	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc42	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc2c	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc33	2026-07-20 11:09:45.616	2026-07-20 11:09:45.616	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbfb	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1e	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf0	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc00	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc01	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc13	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc19	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1c	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf5	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf9	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf2	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbfc	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbfe	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1b	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf7	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc20	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc23	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc27	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc04	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0d	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0f	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc15	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1d	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc14	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc17	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc18	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc24	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf3	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc22	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc28	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbef	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf1	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a539914acd4bc3fec5d2432	2026-07-12 13:39:32.305	2026-07-12 13:39:32.305	\N	biz-004	Sakura Sushi	4	Great fitness studio with excellent equipment and friendly staff. Highly recommend!	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	\N	\N	\N
6a5e01f96f93620f30a5dc03	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc05	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc10	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf6	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf8	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc07	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0c	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc25	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbed	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbee	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbf4	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1f	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc21	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc2a	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc09	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc12	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc26	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbfa	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbff	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc08	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0a	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc16	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Outstanding! The team went above and beyond. Using my One Pass membership here was seamless and the savings were significant.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc1a	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dbfd	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc11	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc02	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc06	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	4	Really enjoyed my visit. Professional team, clean environment, and the discount was a nice bonus with my One Pass membership.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0b	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc0e	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a5e01f96f93620f30a5dc29	2026-07-20 11:09:45.615	2026-07-20 11:09:45.615	\N	biz-004	Sakura Sushi	5	Absolutely fantastic experience! Highly recommend to everyone. The staff was friendly and the quality exceeded my expectations.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	positive	\N	\N
6a539585e18e394fd945ce9b	2026-07-12 13:24:21.625	2026-07-12 13:24:21.625	\N	biz-004	Sakura Sushi	4	Great experience overall! The service was excellent and the atmosphere was very welcoming. Highly recommend to anyone looking for a quality visit.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	pending	t	\N	\N	\N
6a5268e750783316b6dd350f	2026-07-11 16:01:43.303	2026-07-11 16:01:43.303	\N	biz-004	Sakura Sushi	5	Gg	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b0a	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	4	Charming little bookstore with a great selection. Love the author reading events!	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b08	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	4	Great equipment and clean studio. Could use more evening class slots.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b06	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	Best flat white in the city. The 10% discount with OnePass makes my daily coffee even more affordable.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b04	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	Authentic Italian food! The tiramisu is a must-try. 15% off with OnePass is a fantastic deal.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b07	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	Incredible facilities and knowledgeable trainers. The HIIT classes are intense and fun. 20% off is unbeatable!	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b09	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	The facial was amazing! My skin has never looked better. Organic products and professional staff.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b0b	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	Beautiful hotel with excellent service. The rooftop terrace is stunning. OnePass discount made our stay very affordable.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b05	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	5	Perfect pour-over and the pastries are baked fresh every morning. My go-to workspace café.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b03	2026-07-11 15:44:42.426	2026-07-11 15:44:42.426	\N	biz-004	Sakura Sushi	4	Great food and cozy atmosphere. Slightly long wait on a busy Saturday but worth it.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
6a5264ea31e49bf8f4941b02	2026-07-11 15:44:42.425	2026-07-11 15:44:42.425	\N	biz-004	Sakura Sushi	5	Best pasta in Berlin! The carbonara is incredible and the staff is so welcoming. OnePass discount made it even better.	Ahmed Hassan	test_cust_04	\N	\N	\N	\N	\N	\N	f	\N	{}	\N
new_rev_20ded9a3-682b-44b0-9c47-4bd7075d13b9	2026-08-07 22:33:00.788	2026-08-13 09:48:25.886	\N	biz-004	Zen Spa & Wellness	5	Highly recommend! Quality service and excellent savings.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_41bb57b8-5ee9-4fe0-a35c-bcf446232c25	2026-08-12 03:03:44.691	2026-08-13 09:48:25.886	\N	biz-005	FitZone Gym	5	Great service, will definitely return with my membership.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_1a99f16a-c378-4b31-a8ea-16c123dce0b6	2026-08-03 10:33:38.884	2026-08-13 09:48:25.886	\N	biz-006	CineLux Theater	3	Great service, will definitely return with my membership.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_ae0c8b0b-cad4-4d53-b67e-ea7b4c95f973	2026-08-10 18:12:22.227	2026-08-13 09:48:25.886	\N	biz-007	Grand Plaza Hotel	5	Amazing experience! The OnePass discount made it even better.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_576bd3bd-1d72-4795-98ba-8d9674327857	2026-08-11 08:04:39.795	2026-08-13 09:48:25.886	\N	biz-008	Sakura Sushi	3	Great service, will definitely return with my membership.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_987073e9-9c1e-4700-9cac-48bd82a5568e	2026-08-04 03:22:16.081	2026-08-13 09:48:25.886	\N	biz-009	TechHub Electronics	4	Great service, will definitely return with my membership.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_1757c0d2-376b-43dc-ba48-6b9aac35d7a8	2026-08-09 17:56:48.476	2026-08-13 09:48:25.886	\N	biz-010	Sunset Nail Bar	5	Great service, will definitely return with my membership.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_7853ecd2-3941-4889-887a-87fc80e7a34e	2026-08-06 23:37:18.929	2026-08-13 09:48:25.886	\N	biz-001	La Bella Tavola	5	Amazing experience! The OnePass discount made it even better.	Maria Garcia	test_cust_01	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_82cba404-32bc-4b40-9259-91a10733159f	2026-08-10 15:26:34.221	2026-08-13 09:48:25.886	\N	biz-004	Zen Spa & Wellness	5	Highly recommend! Quality service and excellent savings.	James Smith	test_cust_02	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_18278680-c891-4584-8281-74b4ed7fb320	2026-08-09 22:49:32.709	2026-08-13 09:48:25.886	\N	biz-005	FitZone Gym	4	Amazing experience! The OnePass discount made it even better.	James Smith	test_cust_02	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
new_rev_0a85cab8-0c0b-448c-a956-0e67632fe5c4	2026-08-11 19:04:55.907	2026-08-13 09:48:25.886	\N	biz-006	CineLux Theater	5	Great service, will definitely return with my membership.	James Smith	test_cust_02	\N	\N	\N	\N	\N	\N	t	\N	{}	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, is_system, is_active, sort_order, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: saved_segments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_segments (id, business_id, business_name, name, description, criteria, match_count, created_by_id, created_by_name, is_active, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: scheduled_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_reports (id, created_date, updated_date, created_by, name, description, report_type, format, frequency, recipient_email, filters, is_active, last_sent_at, next_run_at, created_by_id, created_by_name, business_id) FROM stdin;
\.


--
-- Data for Name: security_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_incidents (id, created_date, updated_date, created_by, title, description, type, severity, status, target_user_id, target_user_name, target_business_id, target_business_name, assigned_to_id, assigned_to_name, created_by_id, created_by_name, resolution_notes, resolved_at, containment_actions, affected_records, evidence) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, created_date, updated_date, created_by, user_id, token_hash, device_info, ip_address, user_agent, expires_at, is_active, last_activity, description) FROM stdin;
\.


--
-- Data for Name: sla_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sla_configs (id, created_date, updated_date, created_by, name, description, priority, category, first_response_hours, resolution_hours, escalation_enabled, is_active) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, created_date, updated_date, created_by, user_id, user_name, business_id, business_name, plan_id, plan_name, plan_type, amount, currency, billing_cycle, status, start_date, end_date, trial_end_date, auto_renew, payment_method_id, payment_id, cancellation_reason, cancelled_at, renewal_count, description) FROM stdin;
6a5fdf5b3c9d13e1bd06b373	2026-07-21 21:06:35.457	2026-07-22 08:37:48.158	rojsgordons@gmail.com	\N	rojsgordons	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	cancelled	2026-07-21 21:06:35.296	2026-09-03 21:06:35.296	2026-08-04 21:06:35.296	f	\N	\N	User cancelled	2026-07-22 08:37:48.088	0	\N
6a539f470600a6f9ec469743	2026-07-12 14:05:59.69	2026-07-12 14:06:00.099	roygordons15@gmail.com	\N	Roy Gordon	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	trialing	2026-07-12 14:05:59.573	2026-08-25 14:05:59.573	2026-07-26 14:05:59.573	t	\N	\N	\N	\N	0	\N
6a5398d6175d2641a575f2d5	2026-07-12 13:38:30.332	2026-07-12 13:38:30.332	listrakft@gmail.com	\N	Bella Italia Ristorante	\N	Bella Italia Ristorante	\N	Business Pro	business	79.99	EUR	monthly	active	2026-06-01 00:00:00	2026-07-01 00:00:00	\N	t	\N	\N	\N	\N	1	\N
6a5398d6175d2641a575f2b8	2026-07-12 13:38:30.261	2026-07-12 13:38:30.261	listrakft@gmail.com	\N	Sarah Müller	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	active	2026-05-15 10:00:00	2026-08-15 10:00:00	\N	t	\N	\N	\N	\N	2	\N
6a5398d6175d2641a575f29b	2026-07-12 13:38:30.205	2026-07-12 13:38:30.205	listrakft@gmail.com	\N	James Chen	\N	\N	\N	Premium Annual	customer	99.99	EUR	annual	active	2026-01-10 08:00:00	2027-01-10 08:00:00	\N	t	\N	\N	\N	\N	0	\N
6a5398d6175d2641a575f27f	2026-07-12 13:38:30.149	2026-07-12 13:38:30.149	listrakft@gmail.com	\N	Tom Wilson	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	cancelled	2026-03-01 00:00:00	2026-04-01 00:00:00	\N	t	\N	\N	Too expensive	2026-03-28 14:00:00	0	\N
6a5398d6175d2641a575f26e	2026-07-12 13:38:30.09	2026-07-12 13:38:30.09	listrakft@gmail.com	\N	Maria Garcia	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	trialing	2026-07-05 12:00:00	2026-08-05 12:00:00	2026-07-19 12:00:00	t	\N	\N	\N	\N	0	\N
6a527d10fc33763b53b4f355	2026-07-11 17:27:44.784	2026-07-11 17:27:44.784	listrakft@gmail.com	\N	Sarah Müller	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	active	2026-05-15 10:00:00	2026-08-15 10:00:00	\N	t	\N	\N	\N	\N	2	\N
6a527d10fc33763b53b4f359	2026-07-11 17:27:44.784	2026-07-11 17:27:57.121	listrakft@gmail.com	\N	Tom Wilson	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	cancelled	2026-03-01 00:00:00	2026-04-01 00:00:00	\N	t	\N	\N	Too expensive	2026-03-28 14:00:00	0	\N
6a527d10fc33763b53b4f357	2026-07-11 17:27:44.784	2026-07-11 17:27:44.784	listrakft@gmail.com	\N	Bella Italia Ristorante	\N	Bella Italia Ristorante	\N	Business Pro	business	79.99	EUR	monthly	active	2026-06-01 00:00:00	2026-07-01 00:00:00	\N	t	\N	\N	\N	\N	1	\N
6a527d10fc33763b53b4f356	2026-07-11 17:27:44.784	2026-07-11 17:27:44.784	listrakft@gmail.com	\N	James Chen	\N	\N	\N	Premium Annual	customer	99.99	EUR	annual	active	2026-01-10 08:00:00	2027-01-10 08:00:00	\N	t	\N	\N	\N	\N	0	\N
6a527d10fc33763b53b4f358	2026-07-11 17:27:44.784	2026-07-11 17:27:44.784	listrakft@gmail.com	\N	Maria Garcia	\N	\N	\N	Premium Monthly	customer	9.99	EUR	monthly	trialing	2026-07-05 12:00:00	2026-08-05 12:00:00	2026-07-19 12:00:00	t	\N	\N	\N	\N	0	\N
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, user_id, user_name, user_email, business_id, business_name, subject, description, status, priority, category, assigned_to_id, assigned_to_name, resolved_at, resolution_notes, source, requester_type, sla_due_at, first_response_at, csat_rating, csat_comment, merged_into_id, is_escalated, tags, attachments, created_date, updated_date, created_by) FROM stdin;
f35a2f91-3955-4197-b9ab-35120b4e6da6	contact_form	Test	test@test.com	\N	\N	[Contact] Test	From: Test <test@test.com>\n\nMessage:\nHello	open	medium	general	\N	\N	\N	\N	website	customer	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-21 20:27:56.636594+00	2026-08-21 20:27:56.636594+00	\N
a7bb4d6b-0b32-4360-89e0-5a73d07ae7f7	contact_form	x	x@x.com	\N	\N	[Contact] x	From: x <x@x.com>\n\nMessage:\nx	open	medium	general	\N	\N	\N	\N	website	customer	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-21 20:39:44.813954+00	2026-08-21 20:39:44.813954+00	\N
adc9b666-6bf2-4ae3-b131-f73d0b641685	contact_form	Test	test@test.com	\N	\N	[Contact] Test	From: Test <test@test.com>\n\nMessage:\nHello	open	medium	general	\N	\N	\N	\N	website	customer	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-21 20:42:33.49319+00	2026-08-21 20:42:33.49319+00	\N
b69c4544-8caf-4bcb-9130-56255214db5b	17f73fbc-c3f4-4cde-b0da-b90536e8daf0	Test User	test@anerium.com	\N	\N	[Contact] Test User	From: Test User <test@anerium.com>\n\nMessage:\nThis is a test message from the Browserbase automated test.	open	medium	general	\N	\N	\N	\N	website	customer	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-21 21:37:59.343017+00	2026-08-21 21:37:59.343017+00	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, created_date, updated_date, created_by, key, value, description, category, is_public, is_encrypted, is_critical, previous_value, updated_by_id, updated_by_name) FROM stdin;
cmsr5i0n30001p439dqk3txlb	2026-08-13 06:42:20.991	2026-08-13 06:42:20.991	\N	app_name	ANERIUM OnePass	\N	general	t	f	f	\N	\N	\N
cmsr5i0n60002p439lteohxm3	2026-08-13 06:42:20.994	2026-08-13 06:42:20.994	\N	default_currency	EUR	\N	general	t	f	f	\N	\N	\N
cmsr5i0n80003p439v64r94dt	2026-08-13 06:42:20.996	2026-08-13 06:42:20.996	\N	default_language	en	\N	general	t	f	f	\N	\N	\N
cmsr5i0n90004p439zorg7ae3	2026-08-13 06:42:20.998	2026-08-13 06:42:20.998	\N	max_discount_percentage	80	\N	limits	t	f	f	\N	\N	\N
cmsr5i0nb0005p439eq2szg2x	2026-08-13 06:42:20.999	2026-08-13 06:42:20.999	\N	trial_period_days	14	\N	membership	t	f	f	\N	\N	\N
cmsr5i0nd0006p439d9kex7i8	2026-08-13 06:42:21.001	2026-08-13 06:42:21.001	\N	min_password_length	8	\N	security	f	f	f	\N	\N	\N
cmsr5i0ne0007p439dmq56uw2	2026-08-13 06:42:21.003	2026-08-13 06:42:21.003	\N	session_timeout_minutes	60	\N	security	f	f	f	\N	\N	\N
\.


--
-- Data for Name: tax_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_configs (id, description, country, country_code, tax_name, tax_rate, applies_to, is_active, created_by_id, created_by_name, updated_by_id, updated_by_name, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_name, sender_role, body, attachments, is_internal_note, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, created_date, updated_date, created_by, business_id, business_name, customer_id, customer_name, discount_percentage, original_amount, discount_amount, final_amount, status, transaction_date, description) FROM stdin;
txn_708abea3-2e40-433c-b3b9-7e851516b9a2	2026-07-29 18:41:14.627	2026-08-13 09:46:01.163	\N	biz-004	Zen Spa & Wellness	test_cust_01	Maria Garcia	15	50	5	45	completed	2026-08-08 13:03:41.783	\N
txn_17608e0a-ad3f-4054-aa23-17fa22baede1	2026-08-09 17:38:07.647	2026-08-13 09:46:01.163	\N	biz-005	FitZone Gym	test_cust_01	Maria Garcia	15	120	18	45	completed	2026-08-10 21:33:44.048	\N
txn_2e828fce-4cd3-47c9-982a-3223d09ca58d	2026-08-04 03:05:40.652	2026-08-13 09:46:01.163	\N	biz-006	CineLux Theater	test_cust_01	Maria Garcia	15	50	5	45	completed	2026-08-06 14:38:53.654	\N
txn_45507c91-0d5e-4fec-a937-95dd3872748c	2026-07-24 09:55:21.585	2026-08-13 09:46:01.163	\N	biz-007	Grand Plaza Hotel	test_cust_01	Maria Garcia	10	120	18	102	completed	2026-08-01 04:30:57.837	\N
txn_554216ae-3c0e-43bf-9753-4cfdf06493b0	2026-07-24 15:27:48.652	2026-08-13 09:46:01.163	\N	biz-008	Sakura Sushi	test_cust_01	Maria Garcia	15	50	18	45	completed	2026-08-08 19:01:48.494	\N
txn_1a6d551c-5381-4e02-a511-39caf1756917	2026-08-08 18:06:20.589	2026-08-13 09:46:01.163	\N	biz-009	TechHub Electronics	test_cust_01	Maria Garcia	10	50	18	102	completed	2026-07-24 19:51:17.204	\N
txn_49a25a36-ee00-4bb6-87cf-085b23d6f1fd	2026-08-02 20:16:51.52	2026-08-13 09:46:01.163	\N	biz-010	Sunset Nail Bar	test_cust_01	Maria Garcia	15	120	18	45	completed	2026-08-05 04:05:46.386	\N
txn_60baf3c4-c22b-42a4-834b-8b6be981edb1	2026-08-03 08:42:19.668	2026-08-13 09:46:01.163	\N	biz-001	La Bella Tavola	test_cust_01	Maria Garcia	10	50	18	45	completed	2026-07-27 14:57:22.328	\N
txn_9e3b0703-1883-4790-bbf9-c49e28b8281a	2026-08-12 05:26:49.845	2026-08-13 09:46:01.163	\N	biz-004	Zen Spa & Wellness	test_cust_02	James Smith	15	50	5	102	completed	2026-08-07 19:44:45.211	\N
txn_374af5b3-55ca-48f6-8423-5b2e6d8a9d20	2026-08-07 18:48:50.296	2026-08-13 09:46:01.163	\N	biz-005	FitZone Gym	test_cust_02	James Smith	15	50	18	45	completed	2026-08-02 22:06:54.585	\N
txn_4d0a7120-7b57-48ea-9066-8175ab361920	2026-08-04 08:11:58.905	2026-08-13 09:46:01.163	\N	biz-006	CineLux Theater	test_cust_02	James Smith	15	50	18	45	completed	2026-07-30 10:35:26.521	\N
txn_aaad3dc1-2192-4a4b-8b41-8b384e60de57	2026-08-11 21:06:54.041	2026-08-13 09:46:01.163	\N	biz-007	Grand Plaza Hotel	test_cust_02	James Smith	10	120	18	45	completed	2026-07-31 20:10:50.139	\N
txn_e5b3b073-69c4-4052-8b33-ec4a3aa8622f	2026-07-30 22:04:26.653	2026-08-13 09:46:01.163	\N	biz-008	Sakura Sushi	test_cust_02	James Smith	10	50	18	102	completed	2026-07-26 01:57:34.108	\N
txn_45ae5aab-578c-48a5-8f0c-9bf41d91402c	2026-08-09 00:30:10.444	2026-08-13 09:46:01.163	\N	biz-009	TechHub Electronics	test_cust_02	James Smith	10	120	18	102	completed	2026-08-05 00:21:49.085	\N
txn_cfb899e7-d4b3-4e95-9c01-5fdcdaf3e918	2026-08-13 04:20:52.313	2026-08-13 09:46:01.163	\N	biz-010	Sunset Nail Bar	test_cust_02	James Smith	15	120	18	102	completed	2026-07-26 09:23:04.612	\N
txn_ddf913dd-23f9-4112-a7fa-4628ba27b2e6	2026-08-06 00:59:51.179	2026-08-13 09:46:01.163	\N	biz-001	La Bella Tavola	test_cust_02	James Smith	10	120	5	45	completed	2026-07-28 21:58:25.727	\N
txn_fd920e1f-cfa0-4d03-8933-3552645c8f29	2026-08-05 22:32:03.551	2026-08-13 09:46:01.163	\N	biz-004	Zen Spa & Wellness	test_cust_03	Sofia Rossi	15	50	18	102	completed	2026-07-30 07:09:58.184	\N
txn_0689c5a1-4f74-4311-a7c6-09f5d2cd74cf	2026-07-29 19:24:49.929	2026-08-13 09:46:01.163	\N	biz-005	FitZone Gym	test_cust_03	Sofia Rossi	15	120	5	45	completed	2026-08-10 12:53:10.291	\N
txn_1391e606-7ffa-4919-94f5-ba060cb9b6aa	2026-08-04 11:35:37.605	2026-08-13 09:46:01.163	\N	biz-006	CineLux Theater	test_cust_03	Sofia Rossi	10	50	5	45	completed	2026-08-08 06:53:49.405	\N
txn_dfe56d64-f49e-4382-a031-1e2848e0c1cd	2026-08-03 18:08:40.752	2026-08-13 09:46:01.163	\N	biz-007	Grand Plaza Hotel	test_cust_03	Sofia Rossi	15	50	5	45	completed	2026-07-28 13:08:14.868	\N
txn_3c39a46f-f3de-4c28-aecf-f4a7d1395df5	2026-08-04 01:56:40.745	2026-08-13 09:46:01.163	\N	biz-008	Sakura Sushi	test_cust_03	Sofia Rossi	10	50	18	102	completed	2026-07-29 10:00:41.46	\N
txn_c9d6784f-6b88-4506-9d09-9b6c019311b8	2026-08-04 22:07:49.512	2026-08-13 09:46:01.163	\N	biz-009	TechHub Electronics	test_cust_03	Sofia Rossi	10	120	18	45	completed	2026-08-10 16:08:15.31	\N
txn_b2d0c6cc-1e7d-46e3-9376-4d5541612f60	2026-08-09 07:04:04.341	2026-08-13 09:46:01.163	\N	biz-010	Sunset Nail Bar	test_cust_03	Sofia Rossi	15	50	5	45	completed	2026-08-12 00:53:48.893	\N
txn_2051efe6-ae7f-4885-8851-985c13f20bb2	2026-07-24 16:58:47.598	2026-08-13 09:46:01.163	\N	biz-001	La Bella Tavola	test_cust_03	Sofia Rossi	15	120	5	45	completed	2026-08-09 17:35:06.533	\N
txn_5de4cea1-285e-4aa1-b1f7-a948b726bed0	2026-07-29 11:51:59.865	2026-08-13 09:46:01.163	\N	\N	Green Bean Café	test_cust_01	Maria Garcia	10	50	5	102	completed	2026-08-08 20:43:54.348	\N
txn_6b0633ac-705e-44d3-81eb-653ee8fd7806	2026-07-28 15:45:36.968	2026-08-13 09:46:01.163	\N	\N	Green Bean Café	test_cust_02	James Smith	15	120	5	102	completed	2026-08-02 00:03:50.068	\N
txn_c85d4c5e-cfc2-4ec8-9963-6c5a38183c02	2026-08-05 12:39:38.516	2026-08-13 09:46:01.163	\N	\N	Green Bean Café	test_cust_03	Sofia Rossi	10	120	18	102	completed	2026-08-02 03:01:56.839	\N
txn_5d6c0d7b-1c31-447a-a224-6ae0c16a4b64	2026-08-07 20:32:24.673	2026-08-13 09:46:01.163	\N	\N	Style Studio	test_cust_01	Maria Garcia	15	120	18	102	completed	2026-07-30 04:22:02.025	\N
txn_ff6003f0-d44c-4919-abd3-d34f0994dfda	2026-08-02 19:52:42.256	2026-08-13 09:46:01.163	\N	\N	Style Studio	test_cust_02	James Smith	10	120	18	102	completed	2026-08-11 16:54:51.985	\N
txn_6f57ffbf-a2c7-4756-a449-c1de31f8eb1a	2026-08-12 12:30:26.044	2026-08-13 09:46:01.163	\N	\N	Style Studio	test_cust_03	Sofia Rossi	10	50	5	102	completed	2026-08-05 12:11:22.722	\N
\.


--
-- Data for Name: user_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_memberships (id, created_date, updated_date, created_by, user_id, user_name, membership_id, plan_id, plan_name, qr_code_id, status, start_date, end_date, cancellation_reason, cancellation_feedback, cancelled_at, grace_period_ends_at, refund_issued, refund_amount, description) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, created_date, updated_date, created_by, email, password_hash, full_name, role, business_id, phone, is_active, avatar_url) FROM stdin;
cmsr5i0mx0000p4398i3bsvp2	2026-08-13 06:42:20.986	2026-08-13 06:42:20.986	\N	info@anerium.com	$2a$10$aoVkKr1QNkBeXA8anDYyI.vkcWnlu.sCvsUMwziYocg7cDBeUiIiW	System Admin	admin	\N	\N	t	\N
test_cust_01	2026-07-14 09:46:01.161	2026-08-13 09:46:01.161	\N	maria.garcia@email.com	\N	Maria Garcia	member	\N	\N	t	\N
test_cust_02	2026-07-19 09:46:01.161	2026-08-13 09:46:01.161	\N	james.smith@email.com	\N	James Smith	member	\N	\N	t	\N
test_cust_03	2026-07-24 09:46:01.161	2026-08-13 09:46:01.161	\N	sofia.rossi@email.com	\N	Sofia Rossi	member	\N	\N	t	\N
test_cust_04	2026-07-29 09:46:01.161	2026-08-13 09:46:01.161	\N	ahmed.hassan@email.com	\N	Ahmed Hassan	member	\N	\N	t	\N
test_cust_05	2026-08-03 09:46:01.161	2026-08-13 09:46:01.161	\N	emma.johnson@email.com	\N	Emma Johnson	member	\N	\N	t	\N
6c2fcd23-f20e-4255-bd1c-cde01da8e159	2026-08-20 11:31:42.945	2026-08-20 11:31:42.945	\N	testuser@test.com	$2a$10$ETXG8ZpXjTKwxerHmYhVfOlM4SzVeS71omzZmIAU6lo.2lnFNDfGy	Test User	user	\N	\N	t	\N
16ef9b76-523d-4132-a8c7-82b8b93b54fe	2026-08-20 11:37:53.711	2026-08-20 11:37:53.711	\N	listrakft@gmail.com	\N	Mini Wolrd	user	\N	\N	t	https://lh3.googleusercontent.com/a/ACg8ocLux_AMTyDtUNZR6Vd79QMbXz7g92tAf9ZBLDj4pAcRxd6ylwc=s96-c
c51242a7-7503-4c36-a598-332e9da75f3b	2026-08-20 12:08:05.855	2026-08-20 12:08:05.855	\N	roygordons15@gmail.com	\N	Roy Gordon	user	\N	\N	t	https://lh3.googleusercontent.com/a/ACg8ocL_qUn-sN94JH4DHHhIqEBvtZki3TJ__PrxcYaNE7csow483xg=s96-c
cf52e519-a3d3-441b-aaf3-247f97c97f90	2026-08-21 20:45:48.62	2026-08-21 20:45:48.62	\N	test@anerium.com	$2a$10$sbjAK.x736Zyoi1tQ9tkW.S/vLmg//gLUamNULLGGsGmGD.vQtjW2	Test	user	\N	\N	t	\N
17f73fbc-c3f4-4cde-b0da-b90536e8daf0	2026-08-21 21:22:40.627	2026-08-21 21:22:40.627	\N	browser@test.com	$2a$10$UGqGy7UZNV5P0vSV88DOP.FmK7v2WR4P5RPo727cG7KVLaP2CrSEa	Browser Test	user	\N	\N	t	\N
6cbce5b1-0c52-4721-9eab-445d900bcca6	2026-08-22 06:39:55.829	2026-08-22 06:39:55.829	\N	perf1@test.com	$2a$10$Yk2ilRoiceONSxEAv6bdi.xG3CAIX/gYzT9MgWbaaDJOwzsF5OKMS	Perf Test	user	\N	\N	t	\N
9cd51dda-bfa3-4c7a-8888-181978f59191	2026-08-22 06:39:55.941	2026-08-22 06:39:55.941	\N	perf2@test.com	$2a$10$9W3nwgXz22NtcljWRhaLd.63EEJdQGIAed.U5jp6C8nvknFT4JaWe	Perf Test	user	\N	\N	t	\N
d3e62f4b-5c02-42b6-bdd8-b68e3d018966	2026-08-22 06:39:56.041	2026-08-22 06:39:56.041	\N	perf3@test.com	$2a$10$cEppxG5kgAfPqmMVplH4N.Y6zrSJG6JSZamycanVEA7mC8cJ8Hx3i	Perf Test	user	\N	\N	t	\N
672e29aa-3711-4cb3-a9f6-0b1ad05a9d67	2026-08-22 06:40:25.658	2026-08-22 06:40:25.658	\N	leaktest@test.com	$2a$10$awNRg0p2lE1OsQDqJCuZyuetAzwZKijjbDP.cOK30Jgh0TRY9z9ay	Leak Test	user	\N	\N	t	\N
b89bc2e2-8998-46a8-beb1-513191ce0b25	2026-08-22 06:40:39.998	2026-08-22 06:40:39.998	\N	leaktest2@test.com	$2a$10$3/4PsWrEwHUZsn13LDxHlegW.VaF4XN8o24U.XfzrCJqUcme76.zS	Leak Test	user	\N	\N	t	\N
\.


--
-- Data for Name: webhook_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_configs (id, created_date, updated_date, created_by, name, url, events, is_active, secret, headers, last_triggered_at, last_status, failure_count, created_by_id, created_by_name, business_id) FROM stdin;
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_logs (id, description, app_id, app_name, event_type, url, method, payload, response_status, response_body, attempt_count, duration_ms, status, next_retry_at, error_message, is_test, created_date, updated_date, created_by) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: base44_purchases base44_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.base44_purchases
    ADD CONSTRAINT base44_purchases_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: business_categories business_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_categories
    ADD CONSTRAINT business_categories_pkey PRIMARY KEY (id);


--
-- Name: business_documents business_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_documents
    ADD CONSTRAINT business_documents_pkey PRIMARY KEY (id);


--
-- Name: business_email_blasts business_email_blasts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_email_blasts
    ADD CONSTRAINT business_email_blasts_pkey PRIMARY KEY (id);


--
-- Name: business_locations business_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_locations
    ADD CONSTRAINT business_locations_pkey PRIMARY KEY (id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (id);


--
-- Name: campaign_audience campaign_audience_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_audience
    ADD CONSTRAINT campaign_audience_pkey PRIMARY KEY (id);


--
-- Name: campaign_audiences campaign_audiences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_audiences
    ADD CONSTRAINT campaign_audiences_pkey PRIMARY KEY (id);


--
-- Name: campaign_messages campaign_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_messages
    ADD CONSTRAINT campaign_messages_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: commission_payments commission_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commission_payments
    ADD CONSTRAINT commission_payments_pkey PRIMARY KEY (id);


--
-- Name: compliance_requests compliance_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_requests
    ADD CONSTRAINT compliance_requests_pkey PRIMARY KEY (id);


--
-- Name: config_change_logs config_change_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_change_logs
    ADD CONSTRAINT config_change_logs_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: crm_records crm_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_records
    ADD CONSTRAINT crm_records_pkey PRIMARY KEY (id);


--
-- Name: developer_apps developer_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.developer_apps
    ADD CONSTRAINT developer_apps_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: discounts discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts
    ADD CONSTRAINT discounts_pkey PRIMARY KEY (id);


--
-- Name: disputes disputes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disputes
    ADD CONSTRAINT disputes_pkey PRIMARY KEY (id);


--
-- Name: employee_schedules employee_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_schedules
    ADD CONSTRAINT employee_schedules_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: gift_campaigns gift_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_campaigns
    ADD CONSTRAINT gift_campaigns_pkey PRIMARY KEY (id);


--
-- Name: gift_redemptions gift_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_redemptions
    ADD CONSTRAINT gift_redemptions_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: knowledge_bases knowledge_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_bases
    ADD CONSTRAINT knowledge_bases_pkey PRIMARY KEY (id);


--
-- Name: loyalty_points loyalty_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_points
    ADD CONSTRAINT loyalty_points_pkey PRIMARY KEY (id);


--
-- Name: loyalty_tiers loyalty_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_tiers
    ADD CONSTRAINT loyalty_tiers_pkey PRIMARY KEY (id);


--
-- Name: membership_plans membership_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_plans
    ADD CONSTRAINT membership_plans_pkey PRIMARY KEY (id);


--
-- Name: newsletter_subscribers newsletter_subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.newsletter_subscribers
    ADD CONSTRAINT newsletter_subscribers_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- Name: outreach_campaigns outreach_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outreach_campaigns
    ADD CONSTRAINT outreach_campaigns_pkey PRIMARY KEY (id);


--
-- Name: partner_referrals partner_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_referrals
    ADD CONSTRAINT partner_referrals_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: qr_codes qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_pkey PRIMARY KEY (id);


--
-- Name: review_replies review_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_replies
    ADD CONSTRAINT review_replies_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: saved_segments saved_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_segments
    ADD CONSTRAINT saved_segments_pkey PRIMARY KEY (id);


--
-- Name: scheduled_reports scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: security_incidents security_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_incidents
    ADD CONSTRAINT security_incidents_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sla_configs sla_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_configs
    ADD CONSTRAINT sla_configs_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tax_configs tax_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_configs
    ADD CONSTRAINT tax_configs_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_memberships user_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT user_memberships_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_configs webhook_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_configs
    ADD CONSTRAINT webhook_configs_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: blog_posts_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX blog_posts_slug_key ON public.blog_posts USING btree (slug);


--
-- Name: coupons_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX coupons_code_key ON public.coupons USING btree (code);


--
-- Name: developer_apps_api_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX developer_apps_api_key_key ON public.developer_apps USING btree (api_key);


--
-- Name: idx_business_documents_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_documents_business_id ON public.business_documents USING btree (business_id);


--
-- Name: idx_business_email_blasts_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_email_blasts_business_id ON public.business_email_blasts USING btree (business_id);


--
-- Name: idx_business_locations_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_business_locations_business_id ON public.business_locations USING btree (business_id);


--
-- Name: idx_campaign_audience_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_audience_campaign_id ON public.campaign_audience USING btree (campaign_id);


--
-- Name: idx_campaign_messages_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaign_messages_campaign_id ON public.campaign_messages USING btree (campaign_id);


--
-- Name: idx_campaigns_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_campaigns_business_id ON public.campaigns USING btree (business_id);


--
-- Name: idx_chat_messages_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_business_id ON public.chat_messages USING btree (business_id);


--
-- Name: idx_chat_messages_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_user_id ON public.chat_messages USING btree (user_id);


--
-- Name: idx_compliance_requests_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compliance_requests_user_id ON public.compliance_requests USING btree (user_id);


--
-- Name: idx_coupons_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coupons_business_id ON public.coupons USING btree (business_id);


--
-- Name: idx_crm_records_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crm_records_business_id ON public.crm_records USING btree (business_id);


--
-- Name: idx_crm_records_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_crm_records_user_id ON public.crm_records USING btree (user_id);


--
-- Name: idx_devices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_devices_user_id ON public.devices USING btree (user_id);


--
-- Name: idx_discounts_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_discounts_business_id ON public.discounts USING btree (business_id);


--
-- Name: idx_employee_schedules_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_schedules_employee_id ON public.employee_schedules USING btree (employee_id);


--
-- Name: idx_employees_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_business_id ON public.employees USING btree (business_id);


--
-- Name: idx_employees_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_user_id ON public.employees USING btree (user_id);


--
-- Name: idx_favorites_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_favorites_business_id ON public.favorites USING btree (business_id);


--
-- Name: idx_favorites_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_favorites_user_id ON public.favorites USING btree (user_id);


--
-- Name: idx_gift_campaigns_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gift_campaigns_business_id ON public.gift_campaigns USING btree (business_id);


--
-- Name: idx_invoices_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_business_id ON public.invoices USING btree (business_id);


--
-- Name: idx_invoices_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_subscription_id ON public.invoices USING btree (subscription_id);


--
-- Name: idx_loyalty_points_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loyalty_points_user_id ON public.loyalty_points USING btree (user_id);


--
-- Name: idx_loyalty_tiers_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loyalty_tiers_business_id ON public.loyalty_tiers USING btree (business_id);


--
-- Name: idx_notifications_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_business_id ON public.notifications USING btree (business_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_partner_referrals_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_partner_referrals_partner_id ON public.partner_referrals USING btree (partner_id);


--
-- Name: idx_payments_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_business_id ON public.payments USING btree (business_id);


--
-- Name: idx_payments_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_subscription_id ON public.payments USING btree (subscription_id);


--
-- Name: idx_qr_codes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qr_codes_user_id ON public.qr_codes USING btree (user_id);


--
-- Name: idx_review_replies_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_review_replies_business_id ON public.review_replies USING btree (business_id);


--
-- Name: idx_review_replies_review_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_review_replies_review_id ON public.review_replies USING btree (review_id);


--
-- Name: idx_reviews_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_business_id ON public.reviews USING btree (business_id);


--
-- Name: idx_reviews_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_customer_id ON public.reviews USING btree (customer_id);


--
-- Name: idx_scheduled_reports_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scheduled_reports_business_id ON public.scheduled_reports USING btree (business_id);


--
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- Name: idx_subscriptions_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_business_id ON public.subscriptions USING btree (business_id);


--
-- Name: idx_subscriptions_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_plan_id ON public.subscriptions USING btree (plan_id);


--
-- Name: idx_subscriptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_user_id ON public.subscriptions USING btree (user_id);


--
-- Name: idx_transactions_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_business_id ON public.transactions USING btree (business_id);


--
-- Name: idx_transactions_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_customer_id ON public.transactions USING btree (customer_id);


--
-- Name: idx_user_memberships_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_memberships_plan_id ON public.user_memberships USING btree (plan_id);


--
-- Name: idx_user_memberships_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_memberships_user_id ON public.user_memberships USING btree (user_id);


--
-- Name: idx_webhook_configs_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhook_configs_business_id ON public.webhook_configs USING btree (business_id);


--
-- Name: invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX invoices_invoice_number_key ON public.invoices USING btree (invoice_number);


--
-- Name: newsletter_subscribers_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX newsletter_subscribers_email_key ON public.newsletter_subscribers USING btree (email);


--
-- Name: notification_templates_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notification_templates_key_key ON public.notification_templates USING btree (key);


--
-- Name: partner_referrals_referral_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX partner_referrals_referral_code_key ON public.partner_referrals USING btree (referral_code);


--
-- Name: permissions_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_name_key ON public.permissions USING btree (name);


--
-- Name: qr_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qr_codes_code_key ON public.qr_codes USING btree (code);


--
-- Name: qr_codes_qr_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX qr_codes_qr_token_key ON public.qr_codes USING btree (qr_token);


--
-- Name: system_settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX system_settings_key_key ON public.system_settings USING btree (key);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: business_documents business_documents_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_documents
    ADD CONSTRAINT business_documents_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_email_blasts business_email_blasts_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_email_blasts
    ADD CONSTRAINT business_email_blasts_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_locations business_locations_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_locations
    ADD CONSTRAINT business_locations_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_audience campaign_audience_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_audience
    ADD CONSTRAINT campaign_audience_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaign_messages campaign_messages_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaign_messages
    ADD CONSTRAINT campaign_messages_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: campaigns campaigns_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: compliance_requests compliance_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_requests
    ADD CONSTRAINT compliance_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: coupons coupons_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_records crm_records_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_records
    ADD CONSTRAINT crm_records_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: crm_records crm_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crm_records
    ADD CONSTRAINT crm_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: discounts discounts_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discounts
    ADD CONSTRAINT discounts_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employee_schedules employee_schedules_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_schedules
    ADD CONSTRAINT employee_schedules_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: favorites favorites_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: favorites favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: gift_campaigns gift_campaigns_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gift_campaigns
    ADD CONSTRAINT gift_campaigns_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: loyalty_points loyalty_points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_points
    ADD CONSTRAINT loyalty_points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: loyalty_tiers loyalty_tiers_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_tiers
    ADD CONSTRAINT loyalty_tiers_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: partner_referrals partner_referrals_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.partner_referrals
    ADD CONSTRAINT partner_referrals_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: qr_codes qr_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: review_replies review_replies_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_replies
    ADD CONSTRAINT review_replies_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: review_replies review_replies_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_replies
    ADD CONSTRAINT review_replies_review_id_fkey FOREIGN KEY (review_id) REFERENCES public.reviews(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reviews reviews_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reviews reviews_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_reports scheduled_reports_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_reports
    ADD CONSTRAINT scheduled_reports_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscriptions subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.membership_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: transactions transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_memberships user_memberships_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT user_memberships_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.membership_plans(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_memberships user_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_memberships
    ADD CONSTRAINT user_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: webhook_configs webhook_configs_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_configs
    ADD CONSTRAINT webhook_configs_business_id_fkey FOREIGN KEY (business_id) REFERENCES public.businesses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict mLbbTSjqbf1DCeWn8TVa4oAodipCdjQhoaDTq69zaikG75YwWUN4IaFkgNccKLG

